import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { BenoliTreeHero } from './components/BenoliTreeHero';
import { BookGrid } from './components/BookGrid';
import { BookReaderModal } from './components/BookReaderModal';
import { LyricsPlayer } from './components/LyricsPlayer';
import { CharacterGuide } from './components/CharacterGuide';
import { QuizSection } from './components/QuizSection';
import { CommunitySection } from './components/CommunitySection';
import { QuoteGenerator } from './components/QuoteGenerator';
import { RewardsSection } from './components/RewardsSection';
import { AboutAndHelp } from './components/AboutAndHelp';
import { AssistantSalome } from './components/AssistantSalome';
import { Footer } from './components/Footer';

import { ROMANS, Roman, BENOLI_INFO } from './data/benoliData';
import { BookOpen, Sparkles, MessageCircle, Heart, Star, Compass } from 'lucide-react';

export function App() {
  const [activeSection, setActiveSection] = useState<string>('home');
  const [currentLang, setCurrentLang] = useState<string>('fr');
  const [darkMode, setDarkMode] = useState<boolean>(true);
  const [dataSaver, setDataSaver] = useState<boolean>(false);
  const [userPoints, setUserPoints] = useState<number>(120);
  const [favorites, setFavorites] = useState<string[]>(['elle-m-appelait-checo']);
  
  const [selectedRoman, setSelectedRoman] = useState<Roman | null>(null);
  const [selectedSongId, setSelectedSongId] = useState<string | null>(null);

  // Load saved state from localStorage if available
  useEffect(() => {
    try {
      const savedPoints = localStorage.getItem('benoli_user_xp');
      if (savedPoints) setUserPoints(Number(savedPoints));

      const savedFavs = localStorage.getItem('benoli_favorites');
      if (savedFavs) setFavorites(JSON.parse(savedFavs));
    } catch (e) {
      console.error(e);
    }
  }, []);

  const handleRewardXP = (points: number) => {
    setUserPoints(prev => {
      const newTotal = prev + points;
      try { localStorage.setItem('benoli_user_xp', String(newTotal)); } catch (_) {}
      return newTotal;
    });
  };

  const handleToggleFavorite = (id: string) => {
    setFavorites(prev => {
      const next = prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id];
      try { localStorage.setItem('benoli_favorites', JSON.stringify(next)); } catch (_) {}
      return next;
    });
  };

  const handleSelectBookById = (bookId: string) => {
    const r = ROMANS.find(item => item.id === bookId);
    if (r) setSelectedRoman(r);
  };

  const handleSelectSong = (songId: string) => {
    setSelectedSongId(songId);
    setActiveSection('lyrics');
  };

  return (
    <div className={`min-h-screen flex flex-col ${darkMode ? 'bg-[#080d19] text-slate-100' : 'bg-[#f6f3ec] text-slate-900'}`}>
      
      {/* Navigation Topbar */}
      <Navbar
        currentLang={currentLang}
        onLanguageChange={setCurrentLang}
        darkMode={darkMode}
        onToggleDarkMode={() => setDarkMode(!darkMode)}
        dataSaver={dataSaver}
        onToggleDataSaver={() => setDataSaver(!dataSaver)}
        activeSection={activeSection}
        onNavigate={setActiveSection}
        userPoints={userPoints}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-10">
        
        {/* ================= HOME SECTION ================= */}
        {activeSection === 'home' && (
          <div className="space-y-10 animate-in fade-in duration-300">
            
            {/* Retravaillé : L'Arbre Littéraire Vivant avec personnages */}
            <BenoliTreeHero
              onSelectBook={handleSelectBookById}
              dataSaver={dataSaver}
            />

            {/* Quick Feature Shortcut Cards (Facebook Lite Style) */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {[
                { id: 'romans', icon: '📚', title: 'Catalogue 11+ Romans', desc: 'Découvrir les œuvres' },
                { id: 'lyrics', icon: '🎵', title: 'Lyrics & Musiques', desc: 'Écouter les chansons' },
                { id: 'quiz', icon: '🧠', title: 'Quiz Littéraire', desc: 'Quel héros es-tu ?' },
                { id: 'community', icon: '💬', title: 'Club Lecteurs', desc: 'Échanges & réactions' }
              ].map(card => (
                <button
                  key={card.id}
                  onClick={() => setActiveSection(card.id)}
                  className="p-3.5 rounded-2xl bg-slate-900/80 hover:bg-slate-800 border border-amber-500/20 text-left transition-all transform hover:-translate-y-0.5 shadow-lg group"
                >
                  <span className="text-2xl block mb-1">{card.icon}</span>
                  <h4 className="font-serif font-bold text-xs sm:text-sm text-amber-200 group-hover:text-amber-400">
                    {card.title}
                  </h4>
                  <p className="text-[11px] text-slate-400">
                    {card.desc}
                  </p>
                </button>
              ))}
            </div>

            {/* Featured Book Showcase Carousel */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-xs font-extrabold text-amber-400 uppercase tracking-widest block">
                    À ne pas manquer
                  </span>
                  <h3 className="text-xl sm:text-2xl font-serif font-bold text-amber-100">
                    Romans en Vedette
                  </h3>
                </div>
                <button
                  onClick={() => setActiveSection('romans')}
                  className="text-xs text-amber-400 font-bold hover:underline"
                >
                  Tout voir ({ROMANS.length}) →
                </button>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                {ROMANS.filter(r => r.vedette).slice(0, 4).map(roman => (
                  <div
                    key={roman.id}
                    onClick={() => setSelectedRoman(roman)}
                    className="group cursor-pointer rounded-2xl bg-slate-900/80 border border-amber-500/20 hover:border-amber-400/60 overflow-hidden shadow-xl transition-all duration-200 flex flex-col"
                  >
                    <div className="aspect-[2/3] w-full overflow-hidden bg-slate-950 relative">
                      <img
                        src={roman.couverture}
                        alt={roman.titre}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                      />
                      <div className="absolute bottom-2 right-2 px-2 py-0.5 rounded bg-slate-950/90 text-amber-300 text-[11px] font-bold border border-amber-500/30">
                        {roman.prix} FCFA
                      </div>
                    </div>
                    <div className="p-3 space-y-1">
                      <h4 className="font-serif font-bold text-xs sm:text-sm text-amber-100 group-hover:text-amber-300 line-clamp-1">
                        {roman.titre}
                      </h4>
                      <p className="text-[10px] text-slate-400 line-clamp-1">
                        {roman.sousTitre || roman.genre}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Quick Generator Preview */}
            <QuoteGenerator />

          </div>
        )}

        {/* ================= CATALOGUE SECTION ================= */}
        {activeSection === 'romans' && (
          <BookGrid
            onSelectRoman={setSelectedRoman}
            favorites={favorites}
            onToggleFavorite={handleToggleFavorite}
          />
        )}

        {/* ================= LYRICS SECTION ================= */}
        {activeSection === 'lyrics' && (
          <LyricsPlayer
            selectedSongId={selectedSongId}
            onSelectBook={handleSelectBookById}
          />
        )}

        {/* ================= CHARACTERS SECTION ================= */}
        {activeSection === 'characters' && (
          <CharacterGuide
            onSelectBook={handleSelectBookById}
          />
        )}

        {/* ================= QUIZ SECTION ================= */}
        {activeSection === 'quiz' && (
          <QuizSection
            onRewardXP={handleRewardXP}
            onSelectBook={handleSelectBookById}
          />
        )}

        {/* ================= COMMUNITY SECTION ================= */}
        {activeSection === 'community' && (
          <CommunitySection
            onRewardXP={handleRewardXP}
          />
        )}

        {/* ================= QUOTE GENERATOR SECTION ================= */}
        {activeSection === 'quote' && (
          <QuoteGenerator />
        )}

        {/* ================= REWARDS SECTION ================= */}
        {activeSection === 'rewards' && (
          <RewardsSection
            userPoints={userPoints}
          />
        )}

        {/* ================= ABOUT / HELP SECTION ================= */}
        {(activeSection === 'about' || activeSection === 'help') && (
          <AboutAndHelp />
        )}

      </main>

      {/* Interactive Modal for Book Fiche & Reader */}
      <BookReaderModal
        roman={selectedRoman}
        onClose={() => setSelectedRoman(null)}
        onRewardXP={handleRewardXP}
        onSelectSong={handleSelectSong}
      />

      {/* Salomé AI Assistant Floating Button */}
      <AssistantSalome
        onSelectBook={handleSelectBookById}
      />

      {/* Footer */}
      <Footer onNavigate={setActiveSection} />

    </div>
  );
}

export default App;
