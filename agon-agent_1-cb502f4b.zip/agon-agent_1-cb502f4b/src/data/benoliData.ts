export interface Roman {
  id: string;
  titre: string;
  sousTitre?: string;
  genre: string;
  prix: number;
  couverture: string;
  lienAchat: string;
  resume: string;
  extrait: string;
  vedette?: boolean;
  chansonId?: string;
  annee?: number;
  nouveaute?: boolean;
}

export interface Chanson {
  id: string;
  titre: string;
  romanTitre: string;
  romanId: string;
  couverture: string;
  audioUrl: string;
  dureeText: string;
  lyrics: { temps?: number; texte: string }[];
  description: string;
}

export interface Personnage {
  id: string;
  nom: string;
  surnom?: string;
  romanId: string;
  romanTitre: string;
  avatarBg: string;
  emoji: string;
  role: string;
  description: string;
  traits: string[];
  citation: string;
}

export interface Citation {
  id: string;
  texte: string;
  auteur: string;
  roman: string;
  romanId: string;
  likes: number;
}

export const ROMANS: Roman[] = [
  {
    id: "elle-m-appelait-checo",
    titre: "Elle m'appelait Chéco",
    sousTitre: "Je croyais être son ami jusqu'à ce regard.",
    genre: "Roman d'amour & amitié",
    prix: 1000,
    couverture: "/covers/checo.png",
    lienAchat: "https://qlfzgouk.mychariow.shop/prd_5wyolo5v",
    vedette: true,
    chansonId: "checo",
    resume: `Depuis le collège, Benoli et Lénis étaient inséparables. Entre les devoirs, les fous rires, les messages tard dans la nuit et les longues journées de cours, leur amitié semblait simple… presque évidente.
Lénis avait une habitude étrange : elle l’appelait toujours “Chéco”. Un surnom que personne ne comprenait vraiment. Même pas Benoli lui-même.
Mais tout change lorsqu’ils arrivent à l’université. Dans ce nouvel environnement rempli de rencontres, de jalousies, de secrets et de rivalités, leur relation commence lentement à évoluer. Les regards deviennent plus longs. Les silences plus lourds. Les absences plus douloureuses.
Alors que leurs amis pensent assister à une simple amitié, Benoli commence à remarquer des détails qu’il n’avait jamais vus auparavant : la façon dont Lénis le regarde quand une autre fille lui parle… ses réactions étranges… ses messages à des heures impossibles… et cette peur qu’elle semble cacher derrière son sourire.
Entre amour, confusion, pression universitaire, trahisons, ambitions et émotions cachées, Benoli va découvrir que certaines histoires commencent bien avant qu’on ne réalise qu’on est amoureux.
Et peut-être que depuis le début… Lénis ne l’avait jamais appelé “Chéco” par hasard.`,
    extrait: `Le soleil frappait déjà les vitres des salles de classe lorsque Benoli posa son sac au fond de la classe, près de la fenêtre comme d’habitude. Le collège Sainte-Claire n’avait rien de spécial. Les murs étaient vieux, les ventilateurs tournaient difficilement, et les élèves parlaient plus qu’ils n’écoutaient les professeurs.
Mais pour Benoli, cet endroit allait devenir le début d’une histoire qu’il n’oublierait jamais.
— Hé Chéco !
La voix venait du couloir.
Benoli leva les yeux sans même réfléchir. Il connaissait déjà cette voix.
Lénis apparut devant la porte avec son éternel sourire moqueur. Ses cheveux légèrement attachés bougeaient au rythme de ses pas pendant qu’elle avançait vers lui avec assurance.
— Pourquoi tu t’assois toujours au fond ? demanda-t-elle en posant son cahier sur sa table.
— Parce qu’au moins là-bas personne ne me dérange.
— Mensonge. Tu veux juste dormir tranquille.
Benoli esquissa un petit sourire.
Depuis plusieurs mois, Lénis avait pris l’habitude de l’appeler Chéco. Personne ne savait vraiment pourquoi. Même lui ignorait l’origine exacte de ce surnom.
Mais avec le temps… ce mot était devenu normal.
— Tu as fait le devoir de mathématiques ? demanda Lénis en s’asseyant devant lui.
— Peut-être.
— Donc non.
— Peut-être.
Lénis leva les yeux au ciel avant de rire discrètement. C’était toujours comme ça entre eux. Des petites discussions inutiles. Des taquineries, des regards rapides, des habitudes devenues naturelles.
À cette époque, Benoli ne voyait encore rien de spécial dans leur relation. Pour lui, Lénis était juste : sa camarade préférée. Le professeur entra finalement dans la salle avec un bruit sec de dossier qu’on pose sur une table.`
  },
  {
    id: "cobi",
    titre: "Cobi",
    sousTitre: "Et si l'amour ne suffisait pas à nous sauver ?",
    genre: "Roman universitaire & rivalité",
    prix: 1000,
    couverture: "/covers/cobi.png",
    lienAchat: "https://qlfzgouk.mychariow.shop/prd_364l1nm8",
    vedette: true,
    resume: `Depuis le lycée, Bienvenue et Belvida se disputent la première place. Premiers de classe, rivaux aux concours, adversaires en débat — leur relation n'a jamais été une amitié. C'est une guerre silencieuse, polie en apparence, mais féroce en réalité. Belvida lui a donné un surnom qu'elle pensait insultant : « Cobi ». Court pour « Cobra » — un garçon qui frappe froidement, sans jamais montrer ses émotions.
Mais à l'université, le destin les force à collaborer : tous deux élus à la tête d'une même liste pour la présidence d'une association étudiante, obligés de travailler ensemble alors qu'ils s'évitent depuis des années. Et entre les réunions tendues, les votes serrés et les coups bas de leurs propres familles — rivales en affaires depuis longtemps — quelque chose commence lentement à se fissurer dans leur haine.
Belvida le déteste. Ou plutôt, elle voudrait le détester. Parce qu'à chaque fois que Bienvenue gagne, une part d'elle ressent autre chose que de la colère. Et peut-être que ce surnom, « Cobi », n'a jamais voulu dire ce qu'elle prétendait.`,
    extrait: `Le campus de l'université sentait encore la peinture fraîche sur les nouveaux bâtiments administratifs.
C'était la rentrée. Et honnêtement ? Personne n'était vraiment prêt à recommencer les cours après les vacances.
Bienvenue avançait calmement dans l'allée principale, son sac sur une seule épaule, les écouteurs à moitié branchés. Autour de lui : des étudiants partout, des groupes déjà reformés, des cris de retrouvailles, des klaxons de motos-taxis au loin.
Il n'avait pas besoin de chercher longtemps pour savoir qu'elle serait là.
Elle était toujours là.
— BIENVENUE !
La voix venait de loin, mais il la reconnut immédiatement. Cette façon de prononcer son nom comme une accusation.
Il se retourna lentement.
Belvida arrivait vers lui, son cahier de notes serré contre sa poitrine, le menton légèrement levé — cette posture qu'elle adoptait uniquement avec lui.
— Tu as vu les résultats du classement de l'année dernière ? demanda-t-elle directement, sans même un bonjour.
— Bonjour à toi aussi, répondit Bienvenue calmement.
— Réponds.
Il soupira légèrement avant de hausser les épaules.
— Oui. Premier ex-aequo. Comme d'habitude.
— FAUX.
Bienvenue haussa un sourcil.
— J'ai vérifié trois fois, ajouta Belvida en sortant rapidement son téléphone. Premier ex-aequo officiellement. Mais à la moyenne générale exacte... j'étais devant toi de 0,02 point.
Bienvenue la regarda quelques secondes. Puis il éclata doucement de rire.
— Tu as vraiment calculé ça au centième près ?
— Quelqu'un doit garder une trace de la vérité ici.`
  },
  {
    id: "je-ne-suis-pas-ce-qu-ils-ont-fait-de-moi",
    titre: "Je ne suis pas ce qu'ils ont fait de moi",
    sousTitre: "Ce que vous allez lire, c'est l'histoire de comment je suis devenue moi.",
    genre: "Roman de résilience & société",
    prix: 1000,
    couverture: "/covers/je-ne-suis-pas.png",
    lienAchat: "https://qlfzgouk.mychariow.shop/prd_s2swlyhj",
    chansonId: "je-ne-suis-pas",
    vedette: true,
    resume: `Personne ne l'a jamais regardée vraiment. Pas pour ce qu'elle est.
Lénis est belle — tout le monde le voit. Mais derrière ce visage qui attire tous les regards se cache une jeune femme intelligente, blessée, déterminée à prouver qu'elle vaut bien plus que ce que les autres ont décidé d'elle. Dans une ville où les apparences gouvernent tout et où les bonnes familles écrasent les autres, elle décide de jouer le jeu — mais à ses propres règles.
Sur sa route, elle croise Ermine — fille de ministre, manipulatrice née, habituée à ce que tout le monde plie devant elle. Entre ces deux femmes, ce ne sera pas une simple rivalité. Ce sera une guerre.
Et dans cette guerre-là, la plus belle n'est pas forcément celle qu'on croit.`,
    extrait: `On m'a appris très tôt que la vie ne me ferait pas de cadeaux.
Pas parce que j'étais mauvaise. Pas parce que je manquais d'intelligence. Mais parce que dans ce monde-là — le leur — une fille comme moi n'était pas censée réussir. Pas censée briller. Pas censée déranger.
Ils m'ont regardée et ont décidé qui j'étais avant même que j'ouvre la bouche. Ils m'ont mise dans une case, collé une étiquette, et ont tourné les talons.
Ce qu'ils n'avaient pas prévu, c'est que je lirais cette étiquette. Et que je la déchirerais.
Je m'appelle Lenis. Et ce que vous allez lire, c'est l'histoire de comment je suis devenue moi — vraiment moi — malgré tout ce qu'ils ont essayé de faire de moi.
Accrochez-vous.
— Lenis
Le soleil de Cotonou ne faisait pas de cadeau.
Il tapait fort, sans prévenir, dès les premières heures du matin — comme s'il voulait rappeler à tout le monde que la vie ici n'était pas faite pour les faibles. Les rues de Cadjèhoun s'animaient déjà à six heures : les vendeurs de pain installaient leurs plateaux, les motos-taxis klaxonnaient sans raison précise.
Lenis, elle, ne marchait pas vite. Elle avançait. Tranquillement. Les yeux ouverts sur tout.`
  },
  {
    id: "ce-que-tu-m-as-coute",
    titre: "Ce que tu m'as coûté",
    sousTitre: "Certaines blessures ne se voient pas… mais elles coûtent tout",
    genre: "Drame romantique & jeunesse",
    prix: 1000,
    couverture: "/covers/ce-que-tu-mas-coute.jpg",
    lienAchat: "https://qlfzgouk.mychariow.shop/prd_eg8hrg1t",
    resume: `Kévin a quinze ans, une famille simple et aimante, un meilleur ami qui ne le quitte jamais et un rêve : devenir footballeur. Puis il rencontre Mélissa.
Pour elle, il donne tout : son temps, ses amis, ses rêves. Jusqu'au jour où elle le quitte, sans un mot d'explication.
Kévin s'effondre. Mais certaines blessures ne se voient pas, et certains silences cachent bien plus que ce qu'on imagine.
Certaines blessures ne se voient pas… mais elles coûtent tout.`,
    extrait: `Il y avait, dans le regard de Kévin Agbotomey, quelque chose qui ne mentait jamais. Une sorte de lumière douce, presque timide, qui s’allumait dès qu’il souriait. Ce n’était pas le sourire des garçons qui cherchent à se faire remarquer. Ce n’était pas non plus le sourire poli qu’on offre aux adultes pour avoir la paix. C’était plus simple. Plus vrai.
À quinze ans, Kévin n’était pas encore un homme. Mais il n’était plus tout à fait un enfant non plus. Il habitait cet entre-deux fragile où l’on commence à rêver plus loin que le bout de la rue.
Le collège Notre-Dame, à Cotonou, était son univers. Un grand bâtiment ocre, un peu fatigué par les années et par les pluies successives. Le collège sentait la craie, la sueur, la mangue écrasée sous les pieds et, certains jours, l’odeur de la pluie qui arrive trop vite sur la ville.`
  },
  {
    id: "elle-choisit-mal",
    titre: "Elle choisit mal, mais c'est ta faute",
    sousTitre: "Portrait d'une génération amoureuse perdue",
    genre: "Roman psychologique & relation",
    prix: 1000,
    couverture: "/covers/elle-choisit-mal.jpg",
    lienAchat: "https://qlfzgouk.mychariow.shop/prd_2dwwr8zl",
    resume: `Jade a une liste. Dans sa tête, tout est clair : elle veut un homme responsable, sincère, sur qui compter. Nathan est exactement celui-là. Pourtant, c'est Darel, charismatique et imprévisible, qui lui fait oublier ses propres règles.
Pendant que Jade se contredit, Nathan, lassé d'être le bon garçon que personne ne choisit, change d'approche. Et les rôles commencent à s'inverser.
Un roman miroir sur une génération qui dit vouloir une chose et choisit souvent le contraire. Sans juge, sans coupable. Seulement des raisons.`,
    extrait: `Jade avait une liste.
Pas une liste écrite sur papier — elle n'était pas du genre à faire ça. Mais dans sa tête, tout était clair, ordonné, précis comme une équation. Elle savait exactement ce qu'elle voulait chez un homme. Elle l'avait su depuis ses seize ans, et à vingt-deux, rien n'avait changé.
Un homme responsable. Pas parfait — elle n'était pas naïve — mais responsable. Un homme qui savait où il allait dans la vie. Qui avait des projets, des valeurs, une vision. Quelqu'un qui ne disparaissait pas pendant trois jours sans donner de nouvelles.
C'était simple, non ?
Ce soir-là, Jade était assise en tailleur sur son lit, son téléphone posé sur les genoux, pendant que sa meilleure amie Priscille se lamentait depuis l'autre côté de la ligne.`
  },
  {
    id: "la-maison-d-en-face",
    titre: "La Maison d'en face (Tome 1)",
    sousTitre: "Sous le regard des fenêtres, les secrets s'éveillent.",
    genre: "Thriller & secret de famille",
    prix: 1000,
    couverture: "/covers/la-maison-den-face-1.png",
    lienAchat: "https://qlfzgouk.mychariow.shop/prd_4r49bb5o",
    chansonId: "maison-t1",
    vedette: true,
    resume: `La mort mystérieuse de Richard Dossou bouleverse l'existence de son épouse, Élodie. Alors qu'elle tente de surmonter cette tragédie et de reconstruire sa vie, elle se remarie avec Gabriel Ahouansou, un homme aussi attentionné qu'énigmatique. Mais derrière son calme se cache un passé trouble, et sa quête pour comprendre les secrets de la famille Dossou risque de réveiller des vérités que certains préféreraient garder enfouies.
De l'autre côté de la rue, la famille Hounkpe semble vivre paisiblement, loin des drames qui frappent ses voisins. Pourtant, elle aussi porte le poids de son passé. Peu à peu, les destins des deux familles se rapprochent, et des événements inquiétants viennent bouleverser leur tranquillité.`,
    extrait: `La nuit était lourde. L'air du Bénin, saturé d'humidité, collait à la peau comme une seconde enveloppe. Dans le quartier résidentiel de Cotonou, les villas se tenaient alignées, silencieuses. Seule la villa des Dossou restait encore partiellement éclairée. Richard Dossou se tenait sur le balcon du premier étage. Il s'appuyait contre la rambarde en fer forgé.
Il avait bu. Pas beaucoup. Juste assez pour que ses pensées se brouillent un peu, juste assez pour que la peur devienne plus nette.
— Tu n'aurais pas dû venir ce soir, murmura-t-il pour lui-même.`
  },
  {
    id: "la-maison-d-en-face-tome-2",
    titre: "La Maison d'en face – Tome 2",
    sousTitre: "Tome 2 · Quand les ombres se lèvent",
    genre: "Thriller & suspense",
    prix: 1000,
    couverture: "https://images.chariowcdn.com/cdn-cgi/image/format=auto,onerror=redirect,quality=medium-high,slow-connection-quality=50/https://assets.chariowcdn.com/assets/store_avac5msmk10z/KiOtAgIxWo7aK0WpJnQtyjxzFFzlG2OKIW2Ec5rO.jpg",
    lienAchat: "https://qlfzgouk.mychariow.shop/prd_qiyzzl31",
    chansonId: "maison-t2",
    resume: `Deux femmes aux visages presque identiques. Deux maisons qui se font face depuis toujours. Entre elles, des secrets enterrés, des mensonges qui refusent de mourir.
Quand les cendres du passé se ravivent, la vengeance se lève.`,
    extrait: `Il ne répondit pas. Il rangea la photo avec précaution, comme on range une arme.
Le soir même, Nathan frappa à la porte. Seul. Comme d’habitude. Il tenait un nouveau cahier. Plus petit. Mieux caché.
— Maman pleure toujours la nuit, dit-il à Nathalie. Elle parle à quelqu’un qui n’est pas là. Elle dit : « Pourquoi tu es revenue ? » et « Je ne savais pas. » Puis elle s’arrête quand elle entend mes pas.
— Elle a dit un nom ?`
  },
  {
    id: "la-maison-d-en-face-tome-3",
    titre: "La Maison d'en face – Tome 3",
    sousTitre: "Tome 3 · Le dernier tome",
    genre: "Thriller & dénouement",
    prix: 1000,
    couverture: "https://images.chariowcdn.com/cdn-cgi/image/format=auto,onerror=redirect,quality=medium-high,slow-connection-quality=50/https://assets.chariowcdn.com/assets/store_avac5msmk10z/xhiQPxW05g68T9rshTsBCH7BVPFr8yvSzYPvaxkS.jpg",
    lienAchat: "https://qlfzgouk.mychariow.shop/prd_walh6g8t",
    chansonId: "maison-t3",
    resume: `Dans ce troisième et ultime tome, les masques tombent. Les silences se brisent. Les vérités les plus sombres éclatent enfin.
Entre les deux sœurs que tout oppose, la ligne de feu n'a jamais été aussi mince : l'une porte la lumière voilée, l'autre les ombres d'un passé que le sang n'a pas encore lavé.`,
    extrait: `Dans la matinée, Nathalie retourna aux archives avec Gabriel. Cette fois, ils ne cherchaient plus seulement les pages grattées. Ils cherchaient les signatures. Les tampons. Les noms des médecins, des notaires, des familles d’accueil. Chaque piste menait à un autre nom. Chaque nom menait à un silence. Ou à une tombe.
Vers midi, ils trouvèrent une annotation presque illisible dans un registre secondaire : « Affaire confiée à E. — paiement final reçu. Documents détruits. »`
  },
  {
    id: "le-coeur-de-fridaous",
    titre: "Le Cœur de Fridaous",
    sousTitre: "Sans faire de bruit, elle apprend à se construire.",
    genre: "Roman d'inspiration & dépassement",
    prix: 1000,
    couverture: "/covers/fridaous.jpg",
    lienAchat: "https://qlfzgouk.mychariow.shop/prd_s0tk99qc",
    resume: `Fridaous est une jeune femme douce et discrète qui vit à Cotonou avec sa famille. Belle, attentive et réservée, elle préfère rester dans son coin, parle peu et évite les conflits. Sa voix est douce, presque raffinée, mais derrière cette timidité se cache un caractère bien trempé dès qu’il s’agit de se battre pour ce qui compte.
Un jour, elle décide de s’inscrire à une formation — d’abord en informatique, puis en sérigraphie — pour pouvoir travailler et gagner sa vie. Dans ce centre, elle rencontre des camarades avec qui elle tisse de vrais liens. Elle traverse des moments de tristesse, de doutes et de silence, mais elle tient bon. Jour après jour, elle avance, jusqu’à obtenir son diplôme.
C’est l’histoire d’une jeune femme qui, sans faire de bruit, apprend à se construire, à aimer et à prendre sa place.`,
    extrait: `Le soleil de Cotonou n’avait pas encore atteint son zénith, mais la chaleur collait déjà à la peau. Dans la petite cour de la maison familiale, Fridaous était assise sur le banc de bois près du manguier. Ses mains, posées l’une sur l’autre, restaient immobiles. Elle regardait sans vraiment voir les feuilles qui bougeaient faiblement sous la brise tiède.
Ce matin-là, quelque chose avait changé en elle. Depuis des semaines, la même pensée revenait, insistante. Elle ne pouvait plus se contenter d’attendre. Fridaous avait toujours été celle qui restait en retrait. Dans la maison, on disait d’elle qu’elle était « la discrète ». Et c’était vrai. Pourtant, ce matin, une voix intérieure plus forte que sa timidité avait parlé.`
  },
  {
    id: "sessi-mon-etoile",
    titre: "Sessi, mon étoile",
    sousTitre: "Une étoile qui guide, même quand le ciel est sombre.",
    genre: "Roman sentimental & destinée",
    prix: 1000,
    couverture: "https://images.chariowcdn.com/cdn-cgi/image/format=auto,onerror=redirect,quality=medium-high,slow-connection-quality=50/https://assets.chariowcdn.com/assets/store_avac5msmk10z/StyjUzTtFEqMWGrEV1NlpeUoaqRVSmaNNYIi3H9N.jpg",
    lienAchat: "https://qlfzgouk.mychariow.shop/prd_hgqrffai",
    resume: `Sessi est une jeune femme lumineuse et forte, celle qui porte les autres même quand elle-même est fatiguée. Lors d’un voyage d’affaires, elle rencontre Bénoli, un homme en pleine tempête intérieure. Ce qui commence par une simple conversation se transforme en une amitié profonde, puis en un amour sincère et intense.
Mais cet amour est impossible. Entre la famille, les responsabilités, la distance et une rivale déterminée, Sessi et Bénoli devront apprendre que parfois aimer ne suffit pas.
À travers les rires, les silences, les larmes et les moments volés, Sessi restera pour toujours cette étoile qui guide… même quand le ciel est trop sombre.`,
    extrait: `Le soleil se levait à peine sur la ville lorsque Sessi ouvrit les yeux. La lumière douce du matin filtrait à travers les rideaux légèrement entrouverts de sa chambre. Elle resta un instant allongée, les yeux fixés sur le plafond, écoutant le silence de la maison.
Sessi se redressa lentement, s’assit au bord du lit et passa une main dans ses cheveux crépus. Elle sourit faiblement. Même le matin, même fatiguée, il y avait toujours cette petite étincelle en elle. Une étincelle qu’elle n’avait jamais su éteindre, même dans les moments les plus durs.
Dans le couloir, l’odeur du café se mêlait déjà à celle du pain grillé. Maman Adjo était debout, comme toujours.`
  },
  {
    id: "j-ai-appris-a-t-aimer-trop-tard",
    titre: "J’ai appris à t’aimer trop tard",
    sousTitre: "Certaines rencontres arrivent quand on ne croit plus à l’amour.",
    genre: "Roman d'amour & université",
    prix: 1000,
    couverture: "/covers/trop-tard.webp",
    lienAchat: "https://qlfzgouk.mychariow.shop/prd_lzed99ld",
    resume: `Après plusieurs déceptions sentimentales, Samuel décide de ne plus laisser l’amour prendre de place dans sa vie. À l’Université d’Abomey-Calavi, sa rencontre avec Juanita vient pourtant bouleverser cette résolution. Peu à peu, une relation inattendue se construit, faite de confiance, de tendresse et d’espoir. Mais leur histoire devra affronter des épreuves qui rappellent que l’on ne maîtrise ni le temps, ni les événements, ni toujours ce que l’on ressent. Un roman sur les blessures du passé, la force des sentiments et la valeur de chaque instant.`,
    extrait: `Il y a des personnes qui cessent de croire en l'amour après une seule déception. D'autres après deux. Moi, il m'en a fallu cinq.
Cinq histoires. Cinq femmes. Cinq fois où j'ai cru que, cette fois-ci, les choses seraient différentes. Cinq fois où j'avais imaginé que je pourrais construire quelque chose de durable avec quelqu'un. Et cinq fois où j'avais dû apprendre, à ma manière, que les sentiments ne garantissent ni la fidélité, ni la considération, ni même la volonté de rester.
Je ne prétendais pas être un homme parfait. J'étais un étudiant qui essayait de construire son avenir, qui allait à l'université avec des ambitions plein la tête.
La première s'appelait Vanessa.`
  }
];

export const CHANSONS: Chanson[] = [
  {
    id: "checo",
    titre: "Elle m'appelait Chéco (Bande Originale)",
    romanTitre: "Elle m'appelait Chéco",
    romanId: "elle-m-appelait-checo",
    couverture: "/covers/checo.png",
    audioUrl: "/audio/checo.mp3",
    dureeText: "3:45",
    description: "La douce mélodie nostalgique retraçant le lien unique entre Benoli et Lénis au collège Sainte-Claire.",
    lyrics: [
      { texte: "Au fond de la classe près de la fenêtre…" },
      { texte: "Ton rire qui résonne dans tout le couloir." },
      { texte: "Tu m'as dit Chéco sans jamais m'expliquer," },
      { texte: "Mais dans ton regard, l'avenir s'est dessiné." },
      { texte: "Entre les devoirs et les silences complices," },
      { texte: "Je ne savais pas que l'amour nous attendait." }
    ]
  },
  {
    id: "maison-t1",
    titre: "La Maison d'en face (Thème Mystère)",
    romanTitre: "La Maison d'en face (Tome 1)",
    romanId: "la-maison-d-en-face",
    couverture: "/covers/la-maison-den-face-1.png",
    audioUrl: "/audio/maison-t1.mp3",
    dureeText: "3:20",
    description: "Une atmosphère captivante sous la nuit moite de Cotonou et les ombres des balcons.",
    lyrics: [
      { texte: "Les fenêtres s'éteignent une à une dans la rue," },
      { texte: "Seul le balcon des Dossou brille dans l'obscurité." },
      { texte: "Des secrets trop lourds que la terre a reçus," },
      { texte: "Qui frappent à la porte avant le lever du jour." }
    ]
  },
  {
    id: "je-ne-suis-pas",
    titre: "Je ne suis pas ce qu'ils ont fait de moi (Hymne de Lénis)",
    romanTitre: "Je ne suis pas ce qu'ils ont fait de moi",
    romanId: "je-ne-suis-pas-ce-qu-ils-ont-fait-de-moi",
    couverture: "/covers/je-ne-suis-pas.png",
    audioUrl: "/audio/je-ne-suis-pas.mp3",
    dureeText: "2:50",
    description: "Le chant d'émancipation et de résilience d'une femme décidée à déchirer les étiquettes imposées.",
    lyrics: [
      { texte: "Ils ont écrit mon nom avant d'écouter ma voix," },
      { texte: "Mais cette étiquette, je vais la déchirer moi-même." },
      { texte: "Dans les rues de Cadjèhoun sous le soleil de Cotonou," },
      { texte: "Je marche la tête haute, libre et fidèle à mes rêves." }
    ]
  },
  {
    id: "maison-t2",
    titre: "Les Deux Visages (La Maison d'en face T2)",
    romanTitre: "La Maison d'en face – Tome 2",
    romanId: "la-maison-d-en-face-tome-2",
    couverture: "/covers/la-maison-den-face-1.png",
    audioUrl: "/audio/maison-t2.mp3",
    dureeText: "2:15",
    description: "L'affrontement entre la vérité et le silence dans les cahiers secrets.",
    lyrics: [
      { texte: "Deux femmes aux regards presque identiques," },
      { texte: "Des cahiers cachés dans l'ombre d'une chambre." },
      { texte: "Pourquoi est-elle revenue après tant d'années ?" },
      { texte: "La nuit garde encore les traces de leur nom." }
    ]
  },
  {
    id: "maison-t3",
    titre: "Le Dernier Silence (La Maison d'en face T3)",
    romanTitre: "La Maison d'en face – Tome 3",
    romanId: "la-maison-d-en-face-tome-3",
    couverture: "/covers/la-maison-den-face-1.png",
    audioUrl: "/audio/maison-t3.mp3",
    dureeText: "3:10",
    description: "Le grand final musical où la vérité éclate enfin sous la lumière.",
    lyrics: [
      { texte: "Les registres effacés ne cacheront plus le sang," },
      { texte: "La ligne de feu sépare les deux sœurs." },
      { texte: "Quand le soleil se lève enfin sur Cotonou," },
      { texte: "Chaque vérité retrouve son chemin." }
    ]
  }
];

export const PERSONNAGES: Personnage[] = [
  {
    id: "benoli-checo",
    nom: "Benoli",
    surnom: "Chéco",
    romanId: "elle-m-appelait-checo",
    romanTitre: "Elle m'appelait Chéco",
    avatarBg: "from-amber-600 to-amber-900",
    emoji: "🧑‍🎓",
    role: "Protagoniste principal",
    description: "Garçon observateur, fidèle et réservé du collège Sainte-Claire. Il s'assoit au fond près de la fenêtre et ne réalise l'intensité de ses sentiments pour Lénis que tardivement.",
    traits: ["Observateur", "Loyal", "Discret", "Sensible"],
    citation: "« Peut-être que depuis le début… Lénis ne m'avait jamais appelé Chéco par hasard. »"
  },
  {
    id: "lenis",
    nom: "Lénis",
    surnom: "Lénis la mystérieuse",
    romanId: "elle-m-appelait-checo",
    romanTitre: "Elle m'appelait Chéco & Je ne suis pas ce qu'ils ont fait de moi",
    avatarBg: "from-rose-600 to-amber-700",
    emoji: "👩‍🦱",
    role: "Héroïne inoubliable",
    description: "Jeune femme d'une grande beauté et d'une intelligence vive. Elle taquine Benoli avec tendresse et cache derrière sa fierté une soif de vérité et d'indépendance.",
    traits: ["Moqueuse", "Indépendante", "Fière", "Brillante"],
    citation: "« Ils ont collé une étiquette sur moi... Ce qu'ils n'avaient pas prévu, c'est que je lirais cette étiquette et que je la déchirerais. »"
  },
  {
    id: "bienvenue-cobi",
    nom: "Bienvenue",
    surnom: "Cobi (Le Cobra)",
    romanId: "cobi",
    romanTitre: "Cobi",
    avatarBg: "from-emerald-700 to-teal-900",
    emoji: "🐍",
    role: "Rival brillant",
    description: "Étudiant modèle, calme et impassible. Surnommé Cobi par sa rivale Belvida pour sa sang-froid légendaire, il dissimule une profonde sensibilité.",
    traits: ["Calme", "Stratège", "Inébranlable", "Intelligent"],
    citation: "« Premier ex-aequo officiellement. Mais à la vérité, nous étions déjà liés. »"
  },
  {
    id: "belvida",
    nom: "Belvida",
    surnom: "La Combattante",
    romanId: "cobi",
    romanTitre: "Cobi",
    avatarBg: "from-purple-600 to-indigo-900",
    emoji: "👑",
    role: "Rivale passionnée",
    description: "Étudiante ambitieuse au menton toujours levé. Elle calcule ses moyennes au centième près et se bat pour être la première tout en ressentant l'attraction du Cobra.",
    traits: ["Déterminée", "Combative", "Perfectionniste", "Passionnée"],
    citation: "« Quelqu'un doit garder une trace de la vérité ici ! »"
  },
  {
    id: "fridaous",
    nom: "Fridaous",
    surnom: "La Discrète",
    romanId: "le-coeur-de-fridaous",
    romanTitre: "Le Cœur de Fridaous",
    avatarBg: "from-pink-600 to-rose-900",
    emoji: "🌸",
    role: "Modèle de courage",
    description: "Fille douce de Cotonou qui préfère l'ombre et la discrétion. Mais quand il s'agit d'aider sa famille et de faire de la sérigraphie, son courage est immense.",
    traits: ["Douce", "Travailleuse", "Pétrie de valeurs", "Résiliente"],
    citation: "« Sans faire de bruit, on apprend à se construire et à prendre sa place. »"
  },
  {
    id: "sessi",
    nom: "Sessi",
    surnom: "L'Étoile",
    romanId: "sessi-mon-etoile",
    romanTitre: "Sessi, mon étoile",
    avatarBg: "from-cyan-600 to-blue-900",
    emoji: "⭐",
    role: "Guide spirituel & amie",
    description: "Femme forte et solaire qui éclaire la vie des autres même dans les moments sombres. Son amour pour Benoli restera gravé au-delà des obstacles.",
    traits: ["Lumineuse", "Généreuse", "Protectrice", "Unoubliable"],
    citation: "« Sessi restera pour toujours cette étoile qui guide… même quand le ciel est trop sombre. »"
  }
];

export const CITATIONS: Citation[] = [
  {
    id: "cit-1",
    texte: "Certaines histoires commencent bien avant qu'on ne réalise qu'on est amoureux.",
    auteur: "Lokonon B. Tiziano",
    roman: "Elle m'appelait Chéco",
    romanId: "elle-m-appelait-checo",
    likes: 342
  },
  {
    id: "cit-2",
    texte: "Ce qu'ils n'avaient pas prévu, c'est que je lirais cette étiquette et que je la déchirerais.",
    auteur: "Lénis",
    roman: "Je ne suis pas ce qu'ils ont fait de moi",
    romanId: "je-ne-suis-pas-ce-qu-ils-ont-fait-de-moi",
    likes: 289
  },
  {
    id: "cit-3",
    texte: "Certaines blessures ne se voient pas… mais elles coûtent tout.",
    auteur: "Kévin",
    roman: "Ce que tu m'as coûté",
    romanId: "ce-que-tu-m-as-coute",
    likes: 215
  },
  {
    id: "cit-4",
    texte: "Sans faire de bruit, chaque femme apprend à se construire et à prendre sa place dans le monde.",
    auteur: "Fridaous",
    roman: "Le Cœur de Fridaous",
    romanId: "le-coeur-de-fridaous",
    likes: 410
  },
  {
    id: "cit-5",
    texte: "Même quand le ciel est trop sombre, certaines personnes restent des étoiles qui guident nos pas.",
    auteur: "Benoli",
    roman: "Sessi, mon étoile",
    romanId: "sessi-mon-etoile",
    likes: 367
  }
];

export const BENOLI_INFO = {
  nom: "Benoli Olivier Tiziano Houégnon Lokonon",
  plume: "Lokonon B. Tiziano",
  pays: "Bénin 🇧🇯",
  whatsappPrincipal: "2290149293939",
  whatsappFormatted: "+229 01 49 29 39 39",
  contactNumbers: [
    { numero: "2290149293939", label: "WhatsApp Officiel Principal (+229 01 49 29 39 39)" },
    { numero: "2290144699601", label: "Service Lecteurs (+229 01 44 69 96 01)" },
    { numero: "2290152865120", label: "Support mobile (+229 01 52 86 51 20)" }
  ],
  facebookUrl: "https://www.facebook.com/share/1FbFmnhdwq/",
  bioCourte: "Jeune auteur béninois passionné par la création d'histoires riches en émotions, exploration des sentiments humains, rivalités et vérités touchantes.",
  bio: `Benoli Olivier Tiziano Houégnon Lokonon, connu sous le nom de plume Lokonon B. Tiziano, est un jeune auteur béninois passionné par la création d'histoires et l'exploration des émotions humaines.
Depuis son enfance, il possède une imagination débordante et nourrit dans son esprit de nombreuses idées et des univers qu'il exprime à travers la magie de la littérature numérique.
Ses formations en informatique et en graphisme lui ont également permis de concevoir des œuvres complètes avec leurs magnifiques couvertures.
À travers ses romans numériques, Lokonon B. Tiziano explore l'amour, les relations humaines, les secrets de famille, les rivalités et les réalités contemporaines de la jeunesse africaine.
Benoli Littéraire est né de sa volonté de faire rêver, toucher les cœurs et sensibiliser la jeune génération sur le sens de ses choix.`
};
