import React, { useState } from 'react';
import { HelpCircle, Sparkles, RefreshCw, MessageCircle, Share2, Trophy } from 'lucide-react';
import { PERSONNAGES, Personnage } from '../data/benoliData';

interface Question {
  id: number;
  question: string;
  options: { text: string; charId: string }[];
}

const QUIZ_QUESTIONS: Question[] = [
  {
    id: 1,
    question: "Où aimes-tu t'asseoir dans la salle de classe ou à la bibliothèque ?",
    options: [
      { text: "Au fond près de la fenêtre, au calme pour observer.", charId: "benoli-checo" },
      { text: "Au premier rang, prête à poser toutes les questions !", charId: "belvida" },
      { text: "Là où se trouvent mes amies pour rire et taquiner.", charId: "lenis" },
      { text: "Dans un petit coin tranquille pour travailler mes projets.", charId: "fridaous" }
    ]
  },
  {
    id: 2,
    question: "Quelle est ta réaction si un rival te dépasse de 0,02 point ?",
    options: [
      { text: "Je garde mon calme et je souris silencieusement.", charId: "bienvenue-cobi" },
      { text: "Je recompte les moyennes au centième près trois fois !", charId: "belvida" },
      { text: "Je lui donne un surnom moqueur pour me moquer de lui !", charId: "lenis" },
      { text: "Je me reconcentre sur mon travail sans faire de bruit.", charId: "fridaous" }
    ]
  },
  {
    id: 3,
    question: "Comment exprimes-tu tes sentiments amoureux ?",
    options: [
      { text: "Par une amitié fidèle, des regards longs et de la loyauté.", charId: "benoli-checo" },
      { text: "Par des conseils profonds et une lumière constante.", charId: "sessi" },
      { text: "Par des taquineries et des surnoms secrets.", charId: "lenis" },
      { text: "Par des actions concrètes pour soutenir sa famille.", charId: "fridaous" }
    ]
  },
  {
    id: 4,
    question: "Quel est ton plus grand rêve dans la vie ?",
    options: [
      { text: "Changer mon destin et prouver que je suis libre.", charId: "lenis" },
      { text: "Guider mes proches et éclairer les jours sombres.", charId: "sessi" },
      { text: "Réussir ma formation et construire mon indépendance.", charId: "fridaous" },
      { text: "Être toujours le ou la première et triompher.", charId: "belvida" }
    ]
  }
];

interface Props {
  onRewardXP?: (points: number) => void;
  onSelectBook?: (bookId: string) => void;
}

export const QuizSection: React.FC<Props> = ({ onRewardXP, onSelectBook }) => {
  const [currentQuestion, setCurrentQuestion] = useState<number>(0);
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [result, setResult] = useState<Personnage | null>(null);

  const handleSelectOption = (charId: string) => {
    const nextAnswers = { ...answers, [currentQuestion]: charId };
    setAnswers(nextAnswers);

    if (currentQuestion < QUIZ_QUESTIONS.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      // Calculate winner character
      const counts: Record<string, number> = {};
      Object.values(nextAnswers).forEach(id => {
        counts[id] = (counts[id] || 0) + 1;
      });

      let winnerId = "benoli-checo";
      let maxCount = 0;
      Object.entries(counts).forEach(([id, count]) => {
        if (count > maxCount) {
          maxCount = count;
          winnerId = id;
        }
      });

      const matchedChar = PERSONNAGES.find(p => p.id === winnerId) || PERSONNAGES[0];
      setResult(matchedChar);

      if (onRewardXP) {
        onRewardXP(100);
      }
    }
  };

  const resetQuiz = () => {
    setCurrentQuestion(0);
    setAnswers({});
    setResult(null);
  };

  return (
    <section className="rounded-3xl bg-slate-900 border border-amber-500/20 p-5 sm:p-7 text-slate-100 shadow-2xl space-y-6">
      
      {/* Quiz Header */}
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-400 to-amber-600 p-0.5 shadow-lg shadow-amber-950/50 flex items-center justify-center">
          <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
            <Trophy className="w-6 h-6 text-amber-400 animate-bounce" />
          </div>
        </div>
        <div>
          <span className="text-xs font-extrabold text-amber-400 uppercase tracking-widest block">
            Test de personnalité littéraire (+100 XP)
          </span>
          <h2 className="text-2xl sm:text-3xl font-serif font-bold text-amber-100">
            Quel personnage de Benoli es-tu ?
          </h2>
        </div>
      </div>

      {!result ? (
        /* Question Card */
        <div className="space-y-6 bg-slate-950/60 p-5 rounded-2xl border border-amber-500/20">
          
          {/* Progress Indicator */}
          <div className="flex items-center justify-between text-xs text-amber-300/80 font-semibold">
            <span>Question {currentQuestion + 1} sur {QUIZ_QUESTIONS.length}</span>
            <span>{Math.round(((currentQuestion + 1) / QUIZ_QUESTIONS.length) * 100)}% complété</span>
          </div>

          <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
            <div
              className="bg-amber-400 h-full transition-all duration-300"
              style={{ width: `${((currentQuestion + 1) / QUIZ_QUESTIONS.length) * 100}%` }}
            />
          </div>

          <h3 className="font-serif font-bold text-lg sm:text-xl text-amber-200">
            {QUIZ_QUESTIONS[currentQuestion].question}
          </h3>

          <div className="space-y-3">
            {QUIZ_QUESTIONS[currentQuestion].options.map((opt, idx) => (
              <button
                key={idx}
                onClick={() => handleSelectOption(opt.charId)}
                className="w-full p-4 rounded-xl bg-slate-900 hover:bg-amber-500/20 border border-slate-800 hover:border-amber-400/50 text-left text-sm font-medium text-slate-200 hover:text-amber-100 transition-all flex items-center gap-3 transform hover:-translate-y-0.5"
              >
                <span className="w-7 h-7 rounded-lg bg-amber-500/10 text-amber-400 font-bold text-xs flex items-center justify-center border border-amber-500/30 flex-shrink-0">
                  {String.fromCharCode(65 + idx)}
                </span>
                <span>{opt.text}</span>
              </button>
            ))}
          </div>

        </div>
      ) : (
        /* Result Display Card */
        <div className="bg-gradient-to-b from-slate-950 to-slate-900 p-6 rounded-2xl border border-amber-500/40 text-center space-y-5 animate-in zoom-in-95 duration-300">
          
          <span className="text-xs font-bold text-amber-400 uppercase tracking-widest block">
            🎉 Félicitations ! Votre profil révélé (+100 XP Gagnés)
          </span>

          <div className="text-5xl">{result.emoji}</div>

          <h3 className="text-2xl sm:text-3xl font-serif font-bold text-amber-200">
            Tu es : <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-300 to-amber-500">{result.nom}</span>
          </h3>

          <span className="inline-block px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 font-bold text-xs border border-amber-500/30">
            {result.surnom || result.role} • Roman : {result.romanTitre}
          </span>

          <p className="text-sm text-slate-300 max-w-lg mx-auto leading-relaxed bg-slate-900/80 p-4 rounded-xl border border-slate-800">
            {result.description}
          </p>

          <p className="text-xs italic text-amber-300/90 font-serif">
            {result.citation}
          </p>

          {/* Action buttons */}
          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <button
              onClick={() => {
                const text = `J'ai fait le test sur Benoli Littéraire et je suis ${result.nom} (${result.surnom || result.role}) ! Fais le test toi aussi :`;
                const url = window.location.origin + window.location.pathname;
                window.open(`https://wa.me/?text=${encodeURIComponent(text + ' ' + url)}`, '_blank');
              }}
              className="py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg"
            >
              <MessageCircle className="w-4 h-4" />
              <span>Partager sur WhatsApp</span>
            </button>

            {onSelectBook && (
              <button
                onClick={() => onSelectBook(result.romanId)}
                className="py-2.5 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-xs flex items-center gap-2"
              >
                <span>Découvrir son roman</span>
              </button>
            )}

            <button
              onClick={resetQuiz}
              className="py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center gap-2 border border-slate-700"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Recommencer le test</span>
            </button>
          </div>

        </div>
      )}

    </section>
  );
};
