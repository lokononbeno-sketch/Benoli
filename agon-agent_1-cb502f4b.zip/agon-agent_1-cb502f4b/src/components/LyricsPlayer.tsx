import React, { useState, useRef, useEffect } from 'react';
import { Music, Play, Pause, Volume2, VolumeX, Disc, Sparkles, BookOpen } from 'lucide-react';
import { CHANSONS, Chanson } from '../data/benoliData';

interface Props {
  selectedSongId?: string | null;
  onSelectBook?: (bookId: string) => void;
}

export const LyricsPlayer: React.FC<Props> = ({ selectedSongId, onSelectBook }) => {
  const [activeSongIndex, setActiveSongIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(0);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // If selectedSongId changes externally
  useEffect(() => {
    if (selectedSongId) {
      const idx = CHANSONS.findIndex(c => c.id === selectedSongId);
      if (idx !== -1) {
        setActiveSongIndex(idx);
        setIsPlaying(true);
      }
    }
  }, [selectedSongId]);

  const song: Chanson = CHANSONS[activeSongIndex] || CHANSONS[0];

  const togglePlay = () => {
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current.play().then(() => setIsPlaying(true)).catch(console.error);
    }
  };

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      setCurrentTime(audioRef.current.currentTime);
      setDuration(audioRef.current.duration || 0);
    }
  };

  const formatTime = (secs: number) => {
    if (isNaN(secs) || secs === 0) return '0:00';
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <section className="rounded-3xl bg-gradient-to-br from-purple-950/80 via-slate-900 to-indigo-950/80 border border-purple-500/30 p-4 sm:p-7 text-slate-100 shadow-2xl space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-purple-500 to-amber-400 p-0.5 shadow-lg shadow-purple-900/50 flex items-center justify-center">
            <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
              <Music className="w-6 h-6 text-purple-400 animate-pulse" />
            </div>
          </div>
          <div>
            <span className="text-xs font-extrabold text-amber-400 uppercase tracking-widest block">
              L'univers musical de Benoli
            </span>
            <h2 className="text-2xl sm:text-3xl font-serif font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-200 via-pink-200 to-amber-200">
              Lyrics & Musiques des Romans
            </h2>
          </div>
        </div>

        <span className="text-xs text-purple-200/80 bg-purple-900/40 px-3 py-1.5 rounded-full border border-purple-500/30 self-start sm:self-auto">
          🎧 {CHANSONS.length} chansons originales disponibles
        </span>
      </div>

      {/* Main Player Display */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center bg-slate-950/70 p-5 rounded-2xl border border-purple-500/20">
        
        {/* Vinyl / Cover Art Spinning */}
        <div className="md:col-span-5 flex flex-col items-center justify-center text-center space-y-3">
          <div className="relative w-40 h-40 sm:w-48 sm:h-48 rounded-full bg-slate-900 border-4 border-amber-500/30 p-2 shadow-2xl overflow-hidden flex items-center justify-center">
            {/* Spinning Disc Effect */}
            <div className={`w-full h-full rounded-full overflow-hidden relative shadow-inner ${isPlaying ? 'animate-spin' : ''}`} style={{ animationDuration: '12s' }}>
              <img
                src={song.couverture}
                alt={song.titre}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-black/20 rounded-full" />
              <div className="absolute inset-1/2 -translate-x-1/2 -translate-y-1/2 w-10 h-10 bg-slate-950 border-2 border-amber-400 rounded-full flex items-center justify-center shadow-lg">
                <Disc className="w-5 h-5 text-amber-400" />
              </div>
            </div>
          </div>

          <div>
            <h3 className="font-serif font-bold text-base sm:text-lg text-amber-200">
              {song.titre}
            </h3>
            <p className="text-xs text-purple-300/80">
              Chanson associée au roman <strong className="text-amber-300">{song.romanTitre}</strong>
            </p>
          </div>

          {onSelectBook && (
            <button
              onClick={() => onSelectBook(song.romanId)}
              className="text-xs px-3 py-1.5 rounded-xl bg-purple-500/20 hover:bg-purple-500/40 text-purple-200 border border-purple-500/30 font-semibold flex items-center gap-1.5 transition-colors"
            >
              <BookOpen className="w-3.5 h-3.5 text-amber-400" />
              <span>Voir la fiche du roman</span>
            </button>
          )}
        </div>

        {/* Audio Controls & Lyrics Display */}
        <div className="md:col-span-7 space-y-4">
          
          {/* Audio Player Controls */}
          <div className="p-4 rounded-2xl bg-slate-900/90 border border-purple-500/30 space-y-3">
            
            <audio
              ref={audioRef}
              src={song.audioUrl}
              onTimeUpdate={handleTimeUpdate}
              onEnded={() => setIsPlaying(false)}
            />

            <div className="flex items-center justify-between text-xs text-purple-300/80">
              <span>{formatTime(currentTime)}</span>
              <span>{formatTime(duration)}</span>
            </div>

            {/* Progress Bar */}
            <input
              type="range"
              min="0"
              max={duration || 100}
              value={currentTime}
              onChange={(e) => {
                if (audioRef.current) {
                  audioRef.current.currentTime = Number(e.target.value);
                  setCurrentTime(Number(e.target.value));
                }
              }}
              className="w-full accent-amber-400 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
            />

            <div className="flex items-center justify-center gap-4 pt-1">
              <button
                onClick={togglePlay}
                className="w-12 h-12 rounded-full bg-gradient-to-r from-amber-400 to-amber-600 hover:from-amber-500 hover:to-amber-700 text-slate-950 font-bold flex items-center justify-center shadow-lg shadow-amber-950/60 transition-transform transform hover:scale-105"
                aria-label={isPlaying ? "Mettre en pause" : "Écouter la musique"}
              >
                {isPlaying ? <Pause className="w-6 h-6 fill-slate-950" /> : <Play className="w-6 h-6 fill-slate-950 ml-0.5" />}
              </button>
            </div>
          </div>

          {/* Interactive Lyrics Box */}
          <div className="p-4 rounded-2xl bg-slate-900/60 border border-purple-500/20 space-y-2 max-h-48 overflow-y-auto">
            <span className="text-[11px] font-bold text-amber-400 uppercase tracking-wider block">
              Paroles / Lyrics officielles
            </span>
            <div className="space-y-2 font-serif text-sm italic text-purple-100">
              {song.lyrics.map((line, idx) => (
                <p key={idx} className="hover:text-amber-300 transition-colors p-1 rounded bg-purple-900/10">
                  ♫ {line.texte}
                </p>
              ))}
            </div>
          </div>

        </div>

      </div>

      {/* Playlist Grid */}
      <div className="space-y-3">
        <h4 className="text-xs font-extrabold text-amber-300 uppercase tracking-widest">
          Sélectionner une musique de la playlist Benoli
        </h4>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {CHANSONS.map((item, idx) => (
            <button
              key={item.id}
              onClick={() => {
                setActiveSongIndex(idx);
                setIsPlaying(true);
                setTimeout(() => {
                  if (audioRef.current) audioRef.current.play();
                }, 100);
              }}
              className={`p-3 rounded-2xl border text-left transition-all flex items-center gap-3 ${
                activeSongIndex === idx
                  ? 'bg-purple-900/50 border-amber-400 text-amber-200 shadow-md shadow-purple-950/40'
                  : 'bg-slate-900/60 hover:bg-slate-800/80 border-purple-500/20 text-slate-300'
              }`}
            >
              <img
                src={item.couverture}
                alt={item.titre}
                className="w-10 h-10 rounded-xl object-cover flex-shrink-0 border border-purple-500/30"
              />
              <div className="min-w-0 flex-1">
                <h5 className="font-serif font-bold text-xs truncate text-amber-100">
                  {item.titre}
                </h5>
                <p className="text-[10px] text-purple-300/70 truncate">
                  {item.romanTitre}
                </p>
              </div>
              <span className="text-xs font-mono font-bold text-amber-400">
                {item.dureeText}
              </span>
            </button>
          ))}
        </div>
      </div>

    </section>
  );
};
