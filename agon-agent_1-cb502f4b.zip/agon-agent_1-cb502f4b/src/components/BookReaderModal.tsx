import React, { useState, useEffect } from 'react';
import { X, BookOpen, ShoppingBag, MessageCircle, Volume2, VolumeX, Share2, Sparkles, CheckCircle, ArrowLeft, Type, Sun, Moon, Bookmark } from 'lucide-react';
import { Roman, BENOLI_INFO } from '../data/benoliData';

interface Props {
  roman: Roman | null;
  onClose: () => void;
  onRewardXP?: (points: number) => void;
  onSelectSong?: (songId: string) => void;
}

export const BookReaderModal: React.FC<Props> = ({ roman, onClose, onRewardXP, onSelectSong }) => {
  if (!roman) return null;

  const [mode, setMode] = useState<'info' | 'read'>('info');
  const [fontSize, setFontSize] = useState<number>(16);
  const [theme, setTheme] = useState<'light' | 'dark' | 'sepia'>('dark');
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [copiedLien, setCopiedLien] = useState<boolean>(false);
  const [readingProgress, setReadingProgress] = useState<number>(0);
  const [hasEarnedXP, setHasEarnedXP] = useState<boolean>(false);

  // Stop TTS if modal closes
  useEffect(() => {
    return () => {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  const handleSpeak = () => {
    if (!('speechSynthesis' in window)) {
      alert("Votre navigateur ne prend pas en charge la lecture vocale audio.");
      return;
    }

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    } else {
      window.speechSynthesis.cancel();
      const textToRead = `${roman.titre}. ${roman.sousTitre || ''}. ${roman.extrait}`;
      const utterance = new SpeechSynthesisUtterance(textToRead);
      utterance.lang = 'fr-FR';
      utterance.rate = 0.95;
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = () => setIsSpeaking(false);
      window.speechSynthesis.speak(utterance);
      setIsSpeaking(true);
    }
  };

  const handleScrollReading = (e: React.UIEvent<HTMLDivElement>) => {
    const target = e.currentTarget;
    const scrollPercent = Math.round((target.scrollTop / (target.scrollHeight - target.clientHeight)) * 100);
    setReadingProgress(isNaN(scrollPercent) ? 0 : scrollPercent);

    if (scrollPercent > 70 && !hasEarnedXP && onRewardXP) {
      onRewardXP(50);
      setHasEarnedXP(true);
    }
  };

  const shareText = `Je te conseille de lire « ${roman.titre} » de Benoli ! Extrait gratuit disponible ici :`;
  const shareUrl = window.location.origin + window.location.pathname + `#/${roman.id}`;

  const handleShareWhatsApp = () => {
    const waUrl = `https://wa.me/?text=${encodeURIComponent(shareText + ' ' + shareUrl)}`;
    window.open(waUrl, '_blank');
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareUrl).then(() => {
      setCopiedLien(true);
      setTimeout(() => setCopiedLien(false), 2500);
    }).catch(() => {
      prompt("Copiez ce lien :", shareUrl);
    });
  };

  const whatsappDirectLien = `https://wa.me/${BENOLI_INFO.whatsappPrincipal}?text=${encodeURIComponent(`Bonjour Benoli, je suis très intéressé(e) par votre roman « ${roman.titre} » (1000 FCFA).`)}`;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 animate-in fade-in duration-200">
      
      <div className={`w-full max-w-3xl rounded-3xl overflow-hidden shadow-2xl border transition-colors duration-300 flex flex-col max-h-[92vh] ${
        theme === 'dark' ? 'bg-slate-900 border-amber-500/30 text-slate-100' :
        theme === 'sepia' ? 'bg-[#f4ecd8] border-amber-700/30 text-[#433422]' :
        'bg-amber-50/95 border-amber-300 text-slate-900'
      }`}>

        {/* Modal Header Bar */}
        <div className="flex items-center justify-between px-4 sm:px-6 py-3.5 border-b border-amber-500/20 bg-slate-950/40">
          <div className="flex items-center gap-2 min-w-0">
            {mode === 'read' && (
              <button
                onClick={() => setMode('info')}
                className="p-1.5 rounded-lg hover:bg-slate-800 text-amber-400 text-xs font-semibold flex items-center gap-1 mr-1"
              >
                <ArrowLeft className="w-4 h-4" />
                <span className="hidden sm:inline">Retour Fiche</span>
              </button>
            )}
            <span className="font-serif font-bold text-sm sm:text-base text-amber-300 truncate">
              {roman.titre}
            </span>
            <span className="hidden sm:inline-block px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
              {roman.genre}
            </span>
          </div>

          <div className="flex items-center gap-2">
            {mode === 'read' && (
              <div className="flex items-center gap-1 bg-slate-800/80 px-2 py-1 rounded-xl text-xs">
                <button
                  onClick={() => setFontSize(Math.max(13, fontSize - 2))}
                  className="px-1.5 text-amber-300 font-bold hover:text-white"
                  title="Réduire la taille"
                >
                  A-
                </button>
                <span className="text-[11px] text-slate-400">{fontSize}px</span>
                <button
                  onClick={() => setFontSize(Math.min(24, fontSize + 2))}
                  className="px-1.5 text-amber-300 font-bold hover:text-white"
                  title="Agrandir la taille"
                >
                  A+
                </button>
              </div>
            )}

            <button
              onClick={() => {
                if ('speechSynthesis' in window) window.speechSynthesis.cancel();
                onClose();
              }}
              className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
              aria-label="Fermer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Scrollable Body */}
        <div
          onScroll={handleScrollReading}
          className="flex-1 overflow-y-auto p-4 sm:p-7 space-y-6"
        >
          {mode === 'info' ? (
            /* ================= MODE FICHE COMPLETE ================= */
            <div className="space-y-6">
              
              <div className="grid grid-cols-1 sm:grid-cols-12 gap-6 items-start">
                
                {/* Book Cover Image */}
                <div className="sm:col-span-5 flex flex-col items-center">
                  <div className="relative group rounded-2xl overflow-hidden shadow-2xl border border-amber-500/30 max-w-[200px] sm:max-w-full">
                    <img
                      src={roman.couverture}
                      alt={`Couverture de ${roman.titre}`}
                      className="w-full aspect-[2/3] object-cover transition-transform duration-300 group-hover:scale-105"
                      onError={(e) => {
                        // Fallback styling if image fails
                        e.currentTarget.style.display = 'none';
                      }}
                    />
                    <div className="absolute top-2 right-2 px-2.5 py-1 rounded-full bg-amber-500 text-slate-950 font-bold text-xs shadow-md">
                      {roman.prix} FCFA
                    </div>
                  </div>

                  {roman.chansonId && onSelectSong && (
                    <button
                      onClick={() => onSelectSong(roman.chansonId!)}
                      className="mt-3 w-full py-2 px-3 rounded-xl bg-purple-900/40 hover:bg-purple-900/60 border border-purple-500/40 text-purple-200 text-xs font-semibold flex items-center justify-center gap-2 transition-colors"
                    >
                      <span>🎵 Écouter la chanson du roman</span>
                    </button>
                  )}
                </div>

                {/* Book Details */}
                <div className="sm:col-span-7 space-y-4">
                  <div>
                    <span className="text-xs font-bold text-amber-400 uppercase tracking-wider block mb-1">
                      {roman.genre} • Oeuvre Benoli
                    </span>
                    <h2 className="text-2xl sm:text-3xl font-serif font-bold text-amber-200 leading-tight">
                      {roman.titre}
                    </h2>
                    {roman.sousTitre && (
                      <p className="text-sm italic text-amber-300/80 mt-1">
                        {roman.sousTitre}
                      </p>
                    )}
                  </div>

                  <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-200 flex items-center justify-between">
                    <div>
                      <span className="font-bold block">Prix unique numérique :</span>
                      <span className="text-amber-400 font-extrabold text-sm">{roman.prix} FCFA</span>
                    </div>
                    <span className="text-[11px] bg-emerald-600/30 text-emerald-300 px-2.5 py-1 rounded-full font-semibold border border-emerald-500/30">
                      Mobile Money / Card
                    </span>
                  </div>

                  {/* Actions Buttons */}
                  <div className="space-y-2 pt-2">
                    <button
                      onClick={() => setMode('read')}
                      className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500 via-amber-600 to-amber-700 hover:from-amber-600 hover:to-amber-800 text-slate-950 font-extrabold text-sm flex items-center justify-center gap-2 shadow-lg shadow-amber-950/50 transition-all transform hover:-translate-y-0.5"
                    >
                      <BookOpen className="w-4 h-4" />
                      <span>Lire l'extrait gratuit (Immersif)</span>
                    </button>

                    <a
                      href={roman.lienAchat}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/40 transition-colors"
                    >
                      <ShoppingBag className="w-4 h-4" />
                      <span>Acheter le roman complet ({roman.prix} FCFA)</span>
                    </a>

                    <a
                      href={whatsappDirectLien}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-2 border border-slate-700 transition-colors"
                    >
                      <MessageCircle className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Poser une question à Benoli sur WhatsApp</span>
                    </a>
                  </div>
                </div>

              </div>

              {/* Résumé section */}
              <div className="space-y-2 pt-4 border-t border-amber-500/20">
                <h3 className="text-base font-serif font-bold text-amber-300 flex items-center gap-2">
                  <Bookmark className="w-4 h-4 text-amber-400" />
                  <span>Résumé officiel</span>
                </h3>
                <div className="text-sm leading-relaxed text-slate-300 space-y-3 bg-slate-950/40 p-4 rounded-2xl border border-slate-800">
                  {roman.resume.split('\n').map((p, idx) => (
                    <p key={idx}>{p}</p>
                  ))}
                </div>
              </div>

              {/* Extrait Preview Box */}
              <div className="space-y-3 pt-2">
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-serif font-bold text-amber-300">
                    Aperçu de l'extrait gratuit
                  </h3>
                  <button
                    onClick={() => setMode('read')}
                    className="text-xs text-amber-400 hover:underline font-semibold"
                  >
                    Ouvrir en plein écran →
                  </button>
                </div>
                <div className="bg-slate-950/60 p-4 rounded-2xl border border-amber-500/20 text-xs text-slate-300 italic line-clamp-4 leading-relaxed">
                  "{roman.extrait.slice(0, 320)}..."
                </div>
              </div>

              {/* Share Box */}
              <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/20 space-y-3">
                <h4 className="text-xs font-bold text-amber-300 uppercase tracking-wider">
                  Recommander ce roman à vos amies et proches
                </h4>
                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={handleShareWhatsApp}
                    className="py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>WhatsApp</span>
                  </button>
                  <button
                    onClick={handleCopyLink}
                    className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5 border border-slate-700"
                  >
                    <Share2 className="w-3.5 h-3.5 text-amber-400" />
                    <span>{copiedLien ? "Lien copié ✓" : "Copier le lien"}</span>
                  </button>
                </div>
              </div>

            </div>
          ) : (
            /* ================= MODE LISEUSE IMMERSIVE ================= */
            <div className="space-y-6">

              {/* Top Reading toolbar (TTS, Theme, Reading Progress) */}
              <div className="sticky top-0 z-20 flex flex-wrap items-center justify-between gap-3 p-3 rounded-2xl bg-slate-950/80 border border-amber-500/30 backdrop-blur-md shadow-lg">
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleSpeak}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors ${
                      isSpeaking
                        ? 'bg-rose-600 text-white animate-pulse'
                        : 'bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30'
                    }`}
                  >
                    {isSpeaking ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                    <span>{isSpeaking ? "Arrêter la voix" : "Écouter en audio (TTS)"}</span>
                  </button>
                </div>

                <div className="flex items-center gap-2">
                  {/* Theme Switcher */}
                  <button
                    onClick={() => setTheme(theme === 'dark' ? 'light' : theme === 'light' ? 'sepia' : 'dark')}
                    className="px-2.5 py-1.5 rounded-xl bg-slate-800 text-amber-300 text-xs font-semibold border border-slate-700"
                  >
                    {theme === 'dark' ? '🌙 Nuit' : theme === 'light' ? '☀️ Jour' : '📜 Sépiapapier'}
                  </button>

                  <span className="text-xs text-amber-400 font-bold px-2 py-1 bg-amber-500/10 rounded-lg">
                    {readingProgress}% lu
                  </span>
                </div>
              </div>

              {hasEarnedXP && (
                <div className="p-2.5 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-300 text-xs text-center font-bold flex items-center justify-center gap-2 animate-bounce">
                  <Sparkles className="w-4 h-4" />
                  <span>Bravo ! Vous avez gagné +50 XP pour votre lecture.</span>
                </div>
              )}

              {/* Actual Extrait Text Content */}
              <div
                style={{ fontSize: `${fontSize}px` }}
                className="font-serif leading-relaxed space-y-5 p-2 sm:p-4 select-text"
              >
                <div className="text-center pb-4 border-b border-amber-500/20">
                  <span className="text-xs uppercase tracking-widest text-amber-400 font-sans font-bold">
                    Extrait gratuit officiel
                  </span>
                  <h1 className="text-2xl sm:text-3xl font-bold mt-1 text-amber-300">
                    {roman.titre}
                  </h1>
                </div>

                {roman.extrait.split('\n\n').map((paragraph, idx) => (
                  <p key={idx} className="indent-4">
                    {paragraph}
                  </p>
                ))}

                {/* End of Extrait CTA */}
                <div className="pt-8 border-t border-amber-500/30 text-center space-y-4">
                  <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 space-y-2">
                    <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">
                      Fin de l'extrait gratuit
                    </span>
                    <h3 className="text-lg font-serif font-bold text-amber-200">
                      Vous souhaitez connaître la suite de cette histoire captivante ?
                    </h3>
                    <p className="text-xs text-slate-300 max-w-md mx-auto">
                      Procurez-vous le roman complet pour seulement <strong className="text-amber-300">{roman.prix} FCFA</strong>.
                    </p>
                    <a
                      href={roman.lienAchat}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center justify-center gap-2 py-3 px-6 rounded-xl bg-gradient-to-r from-amber-500 to-amber-700 hover:from-amber-600 hover:to-amber-800 text-slate-950 font-extrabold text-sm shadow-xl shadow-amber-950/60 transition-transform transform hover:scale-105"
                    >
                      <ShoppingBag className="w-4 h-4" />
                      <span>Acheter le roman ({roman.prix} FCFA)</span>
                    </a>
                  </div>
                </div>

              </div>

            </div>
          )}
        </div>

      </div>
    </div>
  );
};
