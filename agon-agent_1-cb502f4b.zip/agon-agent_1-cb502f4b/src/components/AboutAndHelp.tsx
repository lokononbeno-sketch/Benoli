import React from 'react';
import { User, MessageCircle, Shield, Award, HelpCircle, CheckCircle, ExternalLink, Heart } from 'lucide-react';
import { BENOLI_INFO } from '../data/benoliData';

export const AboutAndHelp: React.FC = () => {
  return (
    <div className="space-y-8" id="about-help-section">
      
      {/* Author Biography Section */}
      <section className="rounded-3xl bg-slate-900 border border-amber-500/20 p-5 sm:p-8 text-slate-100 shadow-2xl space-y-6">
        
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
          
          <div className="md:col-span-4 flex flex-col items-center text-center space-y-3">
            <div className="relative w-40 h-48 sm:w-48 sm:h-56 rounded-2xl overflow-hidden border-2 border-amber-400 shadow-2xl group">
              <img
                src="/auteur.jpg"
                alt="Portrait de Benoli (Lokonon B. Tiziano)"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                onError={(e) => {
                  e.currentTarget.style.display = 'none';
                }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent opacity-80" />
              <div className="absolute bottom-2 left-2 right-2 text-center">
                <span className="text-[10px] font-bold text-amber-300 bg-slate-950/80 px-2 py-0.5 rounded-full border border-amber-500/30">
                  Auteur Béninois 🇧🇯
                </span>
              </div>
            </div>

            <div>
              <h3 className="font-serif font-bold text-lg text-amber-200">
                {BENOLI_INFO.nom}
              </h3>
              <p className="text-xs text-amber-400 font-medium">
                Nom de plume : <strong>{BENOLI_INFO.plume}</strong>
              </p>
            </div>
          </div>

          <div className="md:col-span-8 space-y-4">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-semibold uppercase tracking-wider">
              <User className="w-3.5 h-3.5 text-amber-400" />
              <span>À propos de l'Auteur</span>
            </div>

            <h2 className="text-2xl sm:text-3xl font-serif font-bold text-amber-100 leading-tight">
              Donner une âme à la littérature numérique béninoise
            </h2>

            <div className="text-xs sm:text-sm text-slate-300 space-y-3 leading-relaxed bg-slate-950/60 p-4 sm:p-5 rounded-2xl border border-slate-800">
              <p>
                <strong>Benoli Olivier Tiziano Houégnon Lokonon</strong>, connu sous le nom de plume <strong className="text-amber-300">Lokonon B. Tiziano</strong>, est un jeune auteur béninois passionné par la création d'histoires et l'exploration des émotions humaines.
              </p>
              <p>
                Ses formations en informatique et en graphisme lui ont également permis de concevoir des œuvres complètes avec leurs magnifiques couvertures.
              </p>
              <p>
                À travers ses romans numériques (<em>Elle m'appelait Chéco</em>, <em>Cobi</em>, <em>Le Cœur de Fridaous</em>, <em>La Maison d'en face</em>...), il aborde l'amour, les relations universitaires, les secrets de famille, les rivalités et invite la jeunesse à réfléchir à la portée de ses choix de vie.
              </p>
            </div>

            {/* Official Contact WhatsApp Buttons */}
            <div className="space-y-2 pt-1">
              <span className="text-xs font-bold text-amber-400 uppercase tracking-wider block">
                Contacts Officiels WhatsApp Benoli :
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                {BENOLI_INFO.contactNumbers.map((c, idx) => (
                  <a
                    key={idx}
                    href={`https://wa.me/${c.numero}?text=${encodeURIComponent("Bonjour Benoli, je vous contacte depuis votre application web !")}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2.5 rounded-xl bg-slate-950 hover:bg-emerald-950/40 border border-emerald-500/30 text-emerald-300 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>WhatsApp {idx + 1}</span>
                  </a>
                ))}
              </div>
            </div>

          </div>

        </div>

      </section>

      {/* Help / FAQ Section */}
      <section className="rounded-3xl bg-slate-900 border border-amber-500/20 p-5 sm:p-8 text-slate-100 shadow-2xl space-y-6" id="faq-section">
        
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center font-bold">
            <HelpCircle className="w-5 h-5" />
          </div>
          <div>
            <span className="text-xs font-extrabold text-amber-400 uppercase tracking-widest block">
              Accompagnement des lecteurs
            </span>
            <h2 className="text-xl sm:text-2xl font-serif font-bold text-amber-100">
              Besoin d'aide & Foire Aux Questions (FAQ)
            </h2>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[
            {
              q: "Comment lire un roman sur l'application ?",
              r: "Il suffit de choisir un titre dans le catalogue et de cliquer sur 'Fiche & Extrait'. Vous pourrez lire l'extrait gratuit immersif, ajuster la taille du texte, changer de thème ou écouter l'extrait en version audio TTS !"
            },
            {
              q: "Comment fonctionne le paiement de 1000 FCFA ?",
              r: "Le paiement s'effectue en toute sécurité via la plateforme officielle Chariow par Mobile Money (MTN, Moov, Celtiis) ou carte bancaire. Vous recevez directement votre livre numérique."
            },
            {
              q: "Puis-je lire sur mon téléphone sans connexion ?",
              r: "Oui ! L'application est optimisée avec notre mode Lite Data Saver pour fonctionner rapidement sur smartphone et sauvegarder vos lectures."
            },
            {
              q: "Que faire en cas de problème d'accès ou de livraison ?",
              r: "En cas de question ou de souci après achat, contactez directement Benoli sur l'un des 3 numéros WhatsApp officiels. L'équipe vous assiste immédiatement !"
            }
          ].map((item, idx) => (
            <div key={idx} className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-2">
              <h4 className="font-serif font-bold text-sm text-amber-200 flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                <span>{item.q}</span>
              </h4>
              <p className="text-xs text-slate-300 leading-relaxed pl-6">
                {item.r}
              </p>
            </div>
          ))}
        </div>

        {/* Facebook Link Banner */}
        <div className="p-4 rounded-2xl bg-blue-950/40 border border-blue-500/30 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
          <div className="space-y-0.5 text-center sm:text-left">
            <h4 className="font-bold text-blue-200 text-sm">
              Rejoignez la communauté Benoli sur Facebook !
            </h4>
            <p className="text-slate-300">
              Suivez toutes les nouveautés, sondages et coulisses des prochains romans.
            </p>
          </div>

          <a
            href={BENOLI_INFO.facebookUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="py-2 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold flex items-center gap-1.5 shadow-md whitespace-nowrap"
          >
            <span>Facebook Benoli ↗</span>
          </a>
        </div>

      </section>

    </div>
  );
};
