import React from 'react';
import { Award, Sparkles, Trophy, CheckCircle2, Shield, Heart, Zap } from 'lucide-react';

interface Props {
  userPoints: number;
}

export const RewardsSection: React.FC<Props> = ({ userPoints }) => {
  const getLevelInfo = (xp: number) => {
    if (xp < 100) return { title: "Apprenti Rêveur", badge: "🌱", next: 100 };
    if (xp < 300) return { title: "Ami de Chéco & Lénis", badge: "📚", next: 300 };
    if (xp < 600) return { title: "Dévoreur de Romans", badge: "🔥", next: 600 };
    if (xp < 1000) return { title: "Gardien de la Littérature", badge: "👑", next: 1000 };
    return { title: "Plume d'Or Benoli", badge: "🏆", next: 2000 };
  };

  const currentLevel = getLevelInfo(userPoints);

  const BADGES = [
    { title: "Première Lecture", desc: "Avoir ouvert et lu un extrait de roman.", xpReq: 50, icon: "📖" },
    { title: "Super Melomane", desc: "Avoir écoute une chanson officielle des romans.", xpReq: 100, icon: "🎵" },
    { title: "Expert Benoli", desc: "Réussi le quiz de personnalité.", xpReq: 150, icon: "🧠" },
    { title: "Ambassadeur", desc: "Partagé une citation ou un roman à un ami.", xpReq: 250, icon: "💬" }
  ];

  return (
    <section className="rounded-3xl bg-slate-900 border border-amber-500/20 p-5 sm:p-7 text-slate-100 shadow-2xl space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-400 via-amber-600 to-amber-700 p-0.5 shadow-lg shadow-amber-950/50 flex items-center justify-center">
            <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
              <Trophy className="w-6 h-6 text-amber-400" />
            </div>
          </div>
          <div>
            <span className="text-xs font-extrabold text-amber-400 uppercase tracking-widest block">
              Pass Lecteur & Gamification
            </span>
            <h2 className="text-2xl sm:text-3xl font-serif font-bold text-amber-100">
              Mes Récompenses Benoli
            </h2>
          </div>
        </div>

        <div className="px-4 py-2 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-300 font-extrabold text-sm flex items-center gap-2 self-start sm:self-auto">
          <Sparkles className="w-4 h-4 animate-pulse text-amber-400" />
          <span>{userPoints} XP accumulés</span>
        </div>
      </div>

      {/* Level Card */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-amber-950/60 via-slate-950 to-slate-900 border border-amber-500/40 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="text-4xl">{currentLevel.badge}</span>
            <div>
              <span className="text-xs text-amber-400 font-bold uppercase tracking-wider block">
                Niveau Actuel du Lecteur
              </span>
              <h3 className="text-xl font-serif font-bold text-amber-200">
                {currentLevel.title}
              </h3>
            </div>
          </div>

          <div className="text-right">
            <span className="text-xs text-slate-400 block font-medium">Prochain niveau :</span>
            <span className="text-xs font-extrabold text-amber-400">{userPoints} / {currentLevel.next} XP</span>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-slate-800 h-3 rounded-full overflow-hidden p-0.5 border border-amber-500/20">
          <div
            className="bg-gradient-to-r from-amber-500 to-amber-300 h-full rounded-full transition-all duration-500"
            style={{ width: `${Math.min(100, (userPoints / currentLevel.next) * 100)}%` }}
          />
        </div>
      </div>

      {/* Badges Grid */}
      <div className="space-y-3">
        <h4 className="text-xs font-extrabold text-amber-400 uppercase tracking-widest">
          Trophées & Badges à débloquer
        </h4>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {BADGES.map((badge, idx) => {
            const isUnlocked = userPoints >= badge.xpReq;

            return (
              <div
                key={idx}
                className={`p-4 rounded-2xl border flex items-center gap-3.5 transition-all ${
                  isUnlocked
                    ? 'bg-slate-950/80 border-amber-500/40 text-amber-100 shadow-md'
                    : 'bg-slate-950/40 border-slate-800 text-slate-500 opacity-60'
                }`}
              >
                <div className="text-3xl flex-shrink-0">{badge.icon}</div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <h5 className="font-serif font-bold text-sm text-amber-200">
                      {badge.title}
                    </h5>
                    {isUnlocked && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
                  </div>
                  <p className="text-xs text-slate-400 truncate">
                    {badge.desc}
                  </p>
                  <span className="text-[10px] text-amber-400/80 font-bold block mt-1">
                    Requis : {badge.xpReq} XP
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

    </section>
  );
};
