import React, { useState } from 'react';
import { Sparkles, BookOpen, Heart, MessageCircle, RefreshCw, Zap } from 'lucide-react';

interface CharacterTalk {
  name: string;
  role: string;
  book: string;
  quote: string;
  color: string;
  avatar: string;
}

const CHARACTERS: Record<string, CharacterTalk> = {
  checo: {
    name: "Benoli & Lénis",
    role: "Les amis d'enfance",
    book: "Elle m'appelait Chéco",
    quote: "« Pourquoi tu t'assois toujours au fond, Chéco ? » — « Parce qu'au moins là-bas personne ne me dérange... sauf toi. »",
    color: "from-amber-500 to-amber-700",
    avatar: "🧑‍🎓👩‍🦱"
  },
  cobi: {
    name: "Bienvenue & Belvida",
    role: "Les rivaux du campus",
    book: "Cobi",
    quote: "« J'ai calculé ta moyenne au centième près : j'étais devant toi de 0,02 point ! » — « Tu as vraiment fait ça, Belvida ? »",
    color: "from-emerald-600 to-teal-800",
    avatar: "🐍👑"
  },
  fridaous: {
    name: "Fridaous",
    role: "La discrète au grand cœur",
    book: "Le Cœur de Fridaous",
    quote: "« Sans faire de bruit, j'apprends à me construire, à créer en sérigraphie et à prendre ma place. »",
    color: "from-rose-500 to-pink-700",
    avatar: "🌸✨"
  },
  sessi: {
    name: "Sessi & Benoli",
    role: "L'étoile et le voyageur",
    book: "Sessi, mon étoile",
    quote: "« Même quand la nuit est trop sombre, certaines âmes restent des étoiles guidant nos pas. »",
    color: "from-cyan-500 to-blue-700",
    avatar: "⭐🌌"
  }
};

interface Props {
  onSelectBook?: (bookId: string) => void;
  dataSaver?: boolean;
}

export const BenoliTreeHero: React.FC<Props> = ({ onSelectBook, dataSaver = false }) => {
  const [activeChar, setActiveChar] = useState<string | null>('checo');
  const [windActive, setWindActive] = useState<boolean>(true);

  const char = activeChar ? CHARACTERS[activeChar] : null;

  return (
    <div className="relative overflow-hidden rounded-3xl bg-gradient-to-b from-[#0e1628] via-[#161f38] to-[#0a1120] text-amber-50 border border-amber-500/20 shadow-2xl transition-all duration-300">
      {/* Background glow effects */}
      <div className="absolute -top-24 -right-24 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-20 -left-20 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Flag accent bar */}
      <div className="h-1.5 w-full bg-gradient-to-r from-emerald-600 via-amber-500 to-rose-600" />

      <div className="p-4 sm:p-7 md:p-8 relative z-10 grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
        
        {/* Left side text */}
        <div className="md:col-span-6 space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-semibold tracking-widest uppercase backdrop-blur-sm">
            <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
            <span>L'Arbre des Histoires Benoli</span>
          </div>

          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-bold text-transparent bg-clip-text bg-gradient-to-r from-amber-100 via-amber-200 to-amber-400 leading-tight">
            Sous l'Arbre de la <span className="italic text-amber-300 underline decoration-amber-500/40">Littérature</span>
          </h1>

          <p className="text-slate-300 text-sm sm:text-base leading-relaxed max-w-lg">
            Bienvenue dans le royaume enchanté de <strong className="text-amber-200">Benoli (Lokonon B. Tiziano)</strong>. 
            Découvre nos romans béninois, leurs chansons et retrouve les personnages vivants rassemblés sous l'arbre poétique !
          </p>

          {/* Interactive Character Dialogue Bubble */}
          {char && (
            <div className="mt-4 p-4 rounded-2xl bg-slate-900/80 border border-amber-500/30 backdrop-blur-md shadow-xl transition-all duration-300 transform animate-in fade-in slide-in-from-bottom-2">
              <div className="flex items-center justify-between gap-3 mb-2">
                <div className="flex items-center gap-2">
                  <span className="text-2xl">{char.avatar}</span>
                  <div>
                    <h4 className="font-bold text-amber-300 text-sm">{char.name}</h4>
                    <span className="text-[11px] text-amber-200/70 font-medium">{char.role} • {char.book}</span>
                  </div>
                </div>
                {onSelectBook && (
                  <button
                    onClick={() => {
                      if (activeChar === 'checo') onSelectBook('elle-m-appelait-checo');
                      else if (activeChar === 'cobi') onSelectBook('cobi');
                      else if (activeChar === 'fridaous') onSelectBook('le-coeur-de-fridaous');
                      else if (activeChar === 'sessi') onSelectBook('sessi-mon-etoile');
                    }}
                    className="text-xs px-2.5 py-1 rounded-lg bg-amber-500/20 hover:bg-amber-500/40 text-amber-200 font-medium transition-colors border border-amber-500/40 flex items-center gap-1"
                  >
                    <BookOpen className="w-3 h-3" />
                    <span>Lire</span>
                  </button>
                )}
              </div>
              <p className="text-xs sm:text-sm italic text-amber-100/90 leading-relaxed bg-black/30 p-2.5 rounded-xl border border-white/5">
                {char.quote}
              </p>
            </div>
          )}

          {/* Quick Character selector buttons */}
          <div className="pt-2">
            <span className="text-xs text-slate-400 font-medium block mb-2">Clique sur un duo sous l'arbre :</span>
            <div className="flex flex-wrap gap-2">
              {Object.entries(CHARACTERS).map(([key, item]) => (
                <button
                  key={key}
                  onClick={() => setActiveChar(key)}
                  className={`text-xs px-3 py-1.5 rounded-xl font-medium transition-all duration-200 flex items-center gap-1.5 border ${
                    activeChar === key
                      ? 'bg-gradient-to-r ' + item.color + ' text-white border-amber-300 shadow-md shadow-amber-900/30 scale-105'
                      : 'bg-slate-800/60 text-slate-300 hover:bg-slate-700/80 border-slate-700/60'
                  }`}
                >
                  <span>{item.avatar.slice(0, 2)}</span>
                  <span>{item.name.split('&')[0]}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right side SVG Tree illustration with characters */}
        <div className="md:col-span-6 relative flex flex-col items-center justify-center min-h-[300px] sm:min-h-[350px]">
          
          {/* Controls top-right */}
          <div className="absolute top-0 right-0 z-20 flex items-center gap-2">
            <button
              onClick={() => setWindActive(!windActive)}
              className="p-1.5 rounded-lg bg-slate-900/80 text-amber-300 hover:text-amber-100 border border-amber-500/30 text-xs flex items-center gap-1 backdrop-blur-sm"
              title="Activer/Désactiver la brise dans l'arbre"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${windActive && !dataSaver ? 'animate-spin' : ''}`} />
              <span className="hidden sm:inline text-[11px]">{windActive ? 'Brise ON' : 'Brise OFF'}</span>
            </button>
          </div>

          {/* SVG Canvas */}
          <div className="w-full max-w-[460px] h-[320px] sm:h-[350px] relative select-none">
            <svg
              viewBox="0 0 520 380"
              className="w-full h-full drop-shadow-[0_15px_25px_rgba(0,0,0,0.6)]"
              aria-label="Illustration fraîche du grand Arbre Benoli avec des personnages de romans béninois lisant à l'ombre"
            >
              <defs>
                {/* Tronc Bark Gradient */}
                <linearGradient id="treeTrunk" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0%" stopColor="#3d2417" />
                  <stop offset="40%" stopColor="#7a4628" />
                  <stop offset="70%" stopColor="#b56f3b" />
                  <stop offset="100%" stopColor="#4a2c18" />
                </linearGradient>

                {/* Canopy Radial Gradients */}
                <radialGradient id="canopyGlow" cx="50%" cy="40%" r="60%">
                  <stop offset="0%" stopColor="#488653" />
                  <stop offset="50%" stopColor="#1e5430" />
                  <stop offset="85%" stopColor="#0f341d" />
                  <stop offset="100%" stopColor="#081e11" />
                </radialGradient>

                <linearGradient id="goldenLeaf" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0%" stopColor="#fef08a" />
                  <stop offset="60%" stopColor="#fbbf24" />
                  <stop offset="100%" stopColor="#d97706" />
                </linearGradient>

                <linearGradient id="emeraldLeaf" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0%" stopColor="#86efac" />
                  <stop offset="60%" stopColor="#22c55e" />
                  <stop offset="100%" stopColor="#15803d" />
                </linearGradient>

                <filter id="softGlow" x="-20%" y="-20%" width="140%" height="140%">
                  <feGaussianBlur stdDeviation="4" result="blur" />
                  <feComposite in="SourceGraphic" in2="blur" operator="over" />
                </filter>
              </defs>

              {/* Sky Background Stars & Magic Particles */}
              <g className="opacity-70">
                <circle cx="80" cy="50" r="1.5" fill="#fef08a" className="animate-ping" style={{ animationDuration: '3s' }} />
                <circle cx="160" cy="30" r="2" fill="#fff" />
                <circle cx="280" cy="40" r="1.5" fill="#fde047" />
                <circle cx="420" cy="65" r="2.5" fill="#fbbf24" className="animate-pulse" />
                <circle cx="460" cy="110" r="1.5" fill="#fff" />
                
                {/* Crescent Moon */}
                <path d="M 440 35 A 18 18 0 0 0 460 65 A 22 22 0 1 1 440 35 Z" fill="#fef08a" opacity="0.85" filter="url(#softGlow)" />
              </g>

              {/* Ground Hill */}
              <path d="M 20 350 Q 260 300 500 350 L 500 380 L 20 380 Z" fill="#142c1e" />
              <path d="M 0 360 Q 260 330 520 365 L 520 380 L 0 380 Z" fill="#0b1b12" />

              {/* Fireflies / Magic Golden Lights */}
              {!dataSaver && (
                <g className="fireflies opacity-80">
                  <circle cx="120" cy="240" r="3" fill="#fef08a" filter="url(#softGlow)" className="animate-bounce" style={{ animationDuration: '4s' }} />
                  <circle cx="220" cy="180" r="2.5" fill="#fde047" className="animate-pulse" />
                  <circle cx="340" cy="220" r="3" fill="#fbbf24" className="animate-bounce" style={{ animationDuration: '5s' }} />
                  <circle cx="390" cy="270" r="2" fill="#fef08a" />
                </g>
              )}

              {/* Main Tree Canopy Foliage Layers */}
              <g className={`tree-leaves ${windActive && !dataSaver ? 'animate-pulse' : ''}`} style={{ animationDuration: '6s' }}>
                {/* Outer Canopy Shadow */}
                <circle cx="260" cy="150" r="135" fill="url(#canopyGlow)" opacity="0.95" />
                <circle cx="170" cy="170" r="85" fill="#144326" opacity="0.9" />
                <circle cx="350" cy="165" r="90" fill="#194d2d" opacity="0.9" />
                <circle cx="260" cy="95" r="80" fill="#256338" opacity="0.85" />
                
                {/* Detailed Leaf Clusters */}
                <circle cx="140" cy="150" r="45" fill="url(#emeraldLeaf)" opacity="0.8" />
                <circle cx="380" cy="140" r="50" fill="url(#emeraldLeaf)" opacity="0.8" />
                <circle cx="230" cy="80" r="40" fill="url(#goldenLeaf)" opacity="0.75" />
                <circle cx="300" cy="75" r="35" fill="url(#goldenLeaf)" opacity="0.75" />

                {/* Decorative Flowers / Golden Fruits */}
                <circle cx="190" cy="120" r="6" fill="#fef08a" />
                <circle cx="320" cy="130" r="7" fill="#fbbf24" />
                <circle cx="250" cy="65" r="5" fill="#f43f5e" />
                <circle cx="130" cy="180" r="6" fill="#fef08a" />
                <circle cx="400" cy="170" r="6" fill="#fbbf24" />
              </g>

              {/* Tree Trunk & Major Branches */}
              <g fill="none" stroke="url(#treeTrunk)" strokeLinecap="round" strokeLinejoin="round">
                {/* Main Trunk */}
                <path d="M 260 360 Q 250 270 260 210 Q 268 170 250 140" strokeWidth="36" />
                
                {/* Roots */}
                <path d="M 250 340 Q 210 355 150 365" strokeWidth="22" />
                <path d="M 270 340 Q 320 355 380 365" strokeWidth="24" />
                <path d="M 260 350 Q 260 365 260 375" strokeWidth="18" />

                {/* Major Branches */}
                <path d="M 255 240 Q 190 220 120 180" strokeWidth="20" />
                <path d="M 262 230 Q 330 205 410 170" strokeWidth="22" />
                <path d="M 258 175 Q 210 140 180 100" strokeWidth="14" />
                <path d="M 260 170 Q 310 135 345 95" strokeWidth="15" />
              </g>

              {/* Wood Highlights & Bark Texture */}
              <g fill="none" stroke="#d97706" strokeLinecap="round" opacity="0.6">
                <path d="M 252 340 Q 242 270 252 210 Q 260 180 248 145" strokeWidth="4" />
                <path d="M 258 310 Q 200 330 140 345" strokeWidth="3" />
                <path d="M 268 310 Q 320 330 370 345" strokeWidth="3" />
              </g>

              {/* ======================================================== */}
              {/* CHARACTERS UNDER THE TREE (INTERACTIVE BENOLI HEROES)  */}
              {/* ======================================================== */}

              {/* 1. Benoli (Chéco) & Lénis Sitting Reading Together under left branch */}
              <g
                className="character-group cursor-pointer transition-transform hover:scale-110"
                onClick={() => setActiveChar('checo')}
                tabIndex={0}
                role="button"
                aria-label="Voir Benoli et Lénis"
              >
                {/* Highlight ring if active */}
                {activeChar === 'checo' && (
                  <ellipse cx="170" cy="335" rx="35" ry="12" fill="#fbbf24" opacity="0.3" className="animate-pulse" />
                )}

                {/* Bench / Mat */}
                <rect x="135" y="335" width="70" height="6" rx="3" fill="#854d0e" />

                {/* Benoli (Left) */}
                {/* Body / Shirt */}
                <path d="M 140 335 C 140 310 155 305 160 335 Z" fill="#2563eb" />
                {/* Head */}
                <circle cx="150" cy="298" r="10" fill="#7c2d12" />
                <circle cx="150" cy="296" r="10" fill="#3b0764" opacity="0.6" /> {/* hair */}
                {/* Book in hands */}
                <path d="M 152 315 L 164 312 L 164 322 L 152 325 Z" fill="#fbbf24" stroke="#fff" strokeWidth="1" />

                {/* Lénis (Right, leaning towards him) */}
                {/* Body / Dress */}
                <path d="M 170 335 C 165 310 185 305 185 335 Z" fill="#e11d48" />
                {/* Head */}
                <circle cx="175" cy="296" r="10" fill="#7c2d12" />
                {/* Braids / Curly Hair */}
                <path d="M 168 290 Q 175 282 182 290 Q 185 302 180 308" fill="#1e1b4b" />
                
                {/* Golden Floating Heart Above Them */}
                <g className="animate-bounce" style={{ animationDuration: '3s' }}>
                  <path d="M 162 280 C 162 276 157 274 154 278 C 151 274 146 276 146 280 C 146 286 154 290 154 290 C 154 290 162 286 162 280 Z" fill="#f43f5e" />
                </g>

                <text x="162" y="352" textAnchor="middle" fill="#fde047" fontSize="10" fontWeight="bold">Chéco & Lénis</text>
              </g>

              {/* 2. Bienvenue (Cobi) & Belvida Standing debating under right branch */}
              <g
                className="character-group cursor-pointer transition-transform hover:scale-110"
                onClick={() => setActiveChar('cobi')}
                tabIndex={0}
                role="button"
                aria-label="Voir Bienvenue Cobi et Belvida"
              >
                {/* Highlight ring if active */}
                {activeChar === 'cobi' && (
                  <ellipse cx="360" cy="335" rx="35" ry="12" fill="#34d399" opacity="0.3" className="animate-pulse" />
                )}

                {/* Cobi (Bienvenue) - Left boy in green jacket */}
                <path d="M 335 338 L 340 310 C 342 300 355 300 352 338 Z" fill="#059669" />
                <circle cx="345" cy="292" r="9" fill="#7c2d12" />

                {/* Belvida - Right girl holding notebook with chin up */}
                <path d="M 365 338 L 368 308 C 372 298 384 300 380 338 Z" fill="#7c3aed" />
                <circle cx="374" cy="290" r="9" fill="#7c2d12" />
                {/* Notebook in hand */}
                <rect x="368" y="308" width="10" height="14" rx="2" fill="#38bdf8" stroke="#fff" strokeWidth="0.8" />

                <text x="360" y="352" textAnchor="middle" fill="#6ee7b7" fontSize="10" fontWeight="bold">Cobi & Belvida</text>
              </g>

              {/* 3. Fridaous under center root shade */}
              <g
                className="character-group cursor-pointer transition-transform hover:scale-110"
                onClick={() => setActiveChar('fridaous')}
                tabIndex={0}
                role="button"
                aria-label="Voir Fridaous"
              >
                {activeChar === 'fridaous' && (
                  <ellipse cx="260" cy="342" rx="25" ry="9" fill="#f43f5e" opacity="0.3" className="animate-pulse" />
                )}
                {/* Sitting Fridaous in yellow/pink pagne */}
                <path d="M 248 340 C 248 322 272 322 272 340 Z" fill="#ec4899" />
                <circle cx="260" cy="316" r="8" fill="#7c2d12" />
                {/* Yellow scarf */}
                <path d="M 254 312 Q 260 306 266 312 Q 268 320 260 322 Z" fill="#facc15" />

                <text x="260" y="354" textAnchor="middle" fill="#f472b6" fontSize="9" fontWeight="bold">Fridaous</text>
              </g>

              {/* Birds in the sky */}
              <g fill="none" stroke="#fde047" strokeWidth="1.5" strokeLinecap="round">
                <path d="M 120 70 Q 128 62 136 70 Q 144 62 152 70" />
                <path d="M 140 85 Q 146 78 152 85 Q 158 78 164 85" />
              </g>
            </svg>
          </div>

          {/* Hint under illustration */}
          <div className="mt-1 text-center">
            <span className="text-[11px] text-amber-200/80 font-medium bg-slate-900/60 px-3 py-1 rounded-full border border-amber-500/20">
              💡 Touche les personnages sous l'arbre pour les entendre !
            </span>
          </div>
        </div>

      </div>
    </div>
  );
};
