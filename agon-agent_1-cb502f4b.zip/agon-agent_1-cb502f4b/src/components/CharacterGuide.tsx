import React, { useState } from 'react';
import { User, Sparkles, BookOpen, Quote, Heart } from 'lucide-react';
import { PERSONNAGES, Personnage } from '../data/benoliData';

interface Props {
  onSelectBook?: (bookId: string) => void;
}

export const CharacterGuide: React.FC<Props> = ({ onSelectBook }) => {
  const [activeCharId, setActiveCharId] = useState<string>(PERSONNAGES[0].id);

  const activeChar = PERSONNAGES.find(p => p.id === activeCharId) || PERSONNAGES[0];

  return (
    <section className="rounded-3xl bg-slate-900 border border-amber-500/20 p-5 sm:p-7 text-slate-100 shadow-2xl space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <span className="text-xs font-extrabold text-amber-400 uppercase tracking-widest block mb-1">
            Univers & Héros des Romans
          </span>
          <h2 className="text-2xl sm:text-3xl font-serif font-bold text-amber-100">
            Guide des Personnages Benoli
          </h2>
        </div>
        <span className="text-xs text-slate-400 font-medium bg-slate-950 px-3 py-1.5 rounded-full border border-slate-800 self-start sm:self-auto">
          🎭 {PERSONNAGES.length} héros emblématiques
        </span>
      </div>

      {/* Grid selector of character avatars */}
      <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 sm:gap-3">
        {PERSONNAGES.map((personnage) => {
          const isActive = personnage.id === activeCharId;

          return (
            <button
              key={personnage.id}
              onClick={() => setActiveCharId(personnage.id)}
              className={`p-3 rounded-2xl border text-center transition-all flex flex-col items-center gap-1.5 ${
                isActive
                  ? 'bg-amber-500/20 border-amber-400 text-amber-200 shadow-lg shadow-amber-950/40 scale-105'
                  : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 text-slate-400'
              }`}
            >
              <div className={`w-12 h-12 rounded-full bg-gradient-to-br ${personnage.avatarBg} text-2xl flex items-center justify-center shadow-md border-2 border-amber-400/40`}>
                {personnage.emoji}
              </div>
              <span className="font-bold text-xs truncate max-w-full">
                {personnage.nom}
              </span>
            </button>
          );
        })}
      </div>

      {/* Detailed Character Card */}
      <div className="p-6 rounded-2xl bg-slate-950/80 border border-amber-500/30 space-y-5 animate-in fade-in duration-200">
        
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-amber-500/20 pb-4">
          <div className="flex items-center gap-4">
            <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${activeChar.avatarBg} text-4xl flex items-center justify-center shadow-xl border-2 border-amber-400`}>
              {activeChar.emoji}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-2xl font-serif font-bold text-amber-200">
                  {activeChar.nom}
                </h3>
                {activeChar.surnom && (
                  <span className="text-xs px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30">
                    « {activeChar.surnom} »
                  </span>
                )}
              </div>
              <p className="text-xs text-amber-400/90 font-semibold mt-0.5">
                {activeChar.role} • Roman : <strong className="text-amber-200">{activeChar.romanTitre}</strong>
              </p>
            </div>
          </div>

          {onSelectBook && (
            <button
              onClick={() => onSelectBook(activeChar.romanId)}
              className="py-2 px-3.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-700 hover:from-amber-600 hover:to-amber-800 text-slate-950 font-extrabold text-xs flex items-center gap-1.5 shadow-md self-start sm:self-auto"
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Voir le roman ({activeChar.romanTitre})</span>
            </button>
          )}
        </div>

        {/* Traits Pills */}
        <div className="flex flex-wrap gap-2">
          {activeChar.traits.map((trait, idx) => (
            <span
              key={idx}
              className="px-2.5 py-1 rounded-lg bg-slate-900 text-amber-300 text-xs font-semibold border border-amber-500/20"
            >
              • {trait}
            </span>
          ))}
        </div>

        {/* Description & Citation */}
        <div className="space-y-3">
          <p className="text-sm text-slate-300 leading-relaxed bg-slate-900/60 p-4 rounded-xl border border-slate-800">
            {activeChar.description}
          </p>

          <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs italic text-amber-200 font-serif flex items-start gap-2">
            <Quote className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
            <span>{activeChar.citation}</span>
          </div>
        </div>

      </div>

    </section>
  );
};
