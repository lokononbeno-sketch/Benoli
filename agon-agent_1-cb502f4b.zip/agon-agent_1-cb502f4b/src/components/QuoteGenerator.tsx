import React, { useState } from 'react';
import { Sparkles, Share2, Download, Copy, RefreshCw, MessageCircle } from 'lucide-react';
import { CITATIONS, Citation } from '../data/benoliData';

export const QuoteGenerator: React.FC = () => {
  const [selectedCitationIndex, setSelectedCitationIndex] = useState<number>(0);
  const [bgStyle, setBgStyle] = useState<'gold' | 'emerald' | 'cosmic' | 'sunset'>('gold');
  const [copiedText, setCopiedText] = useState<boolean>(false);

  const cit: Citation = CITATIONS[selectedCitationIndex] || CITATIONS[0];

  const bgClasses = {
    gold: "from-[#2b1f14] via-[#422d18] to-[#1a120b] border-amber-500/50 text-amber-100",
    emerald: "from-[#0a2016] via-[#123826] to-[#06140e] border-emerald-500/50 text-emerald-100",
    cosmic: "from-[#1b122e] via-[#2c184d] to-[#0f091c] border-purple-500/50 text-purple-100",
    sunset: "from-[#2e1319] via-[#4d1d27] to-[#1c0a0e] border-rose-500/50 text-rose-100"
  };

  const handleNextCitation = () => {
    setSelectedCitationIndex((prev) => (prev + 1) % CITATIONS.length);
  };

  const shareText = `« ${cit.texte} » — ${cit.auteur} (${cit.roman})`;
  const shareUrl = window.location.origin + window.location.pathname;

  const handleShareWhatsApp = () => {
    window.open(`https://wa.me/?text=${encodeURIComponent(shareText + '\n\n' + shareUrl)}`, '_blank');
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(`${shareText}\n${shareUrl}`).then(() => {
      setCopiedText(true);
      setTimeout(() => setCopiedText(false), 2500);
    });
  };

  return (
    <section className="rounded-3xl bg-slate-900 border border-amber-500/20 p-5 sm:p-7 text-slate-100 shadow-2xl space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center font-bold">
            ✍️
          </div>
          <div>
            <span className="text-xs font-extrabold text-amber-400 uppercase tracking-widest block">
              Inspiration & Statut WhatsApp
            </span>
            <h2 className="text-xl sm:text-2xl font-serif font-bold text-amber-100">
              Générateur de Citations Benoli
            </h2>
          </div>
        </div>

        {/* Style selector */}
        <div className="flex items-center gap-1.5 self-start sm:self-auto bg-slate-950 p-1 rounded-xl border border-slate-800">
          {(['gold', 'emerald', 'cosmic', 'sunset'] as const).map((st) => (
            <button
              key={st}
              onClick={() => setBgStyle(st)}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold capitalize transition-colors ${
                bgStyle === st
                  ? 'bg-amber-500 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Quote Preview Card */}
      <div className={`p-8 sm:p-12 rounded-3xl bg-gradient-to-br ${bgClasses[bgStyle]} border-2 shadow-2xl space-y-6 relative overflow-hidden text-center`}>
        
        {/* Decorative Quote Mark */}
        <span className="absolute -top-4 -left-2 text-8xl font-serif opacity-15 select-none font-bold">
          “
        </span>
        <span className="absolute -bottom-10 -right-2 text-8xl font-serif opacity-15 select-none font-bold">
          ”
        </span>

        <p className="font-serif italic text-lg sm:text-2xl lg:text-3xl leading-relaxed font-semibold relative z-10 max-w-2xl mx-auto">
          « {cit.texte} »
        </p>

        <div className="relative z-10 pt-2 border-t border-white/10 max-w-md mx-auto">
          <h4 className="font-bold text-sm sm:text-base tracking-wide">
            {cit.auteur}
          </h4>
          <span className="text-xs opacity-75 font-medium block mt-0.5">
            Roman : {cit.roman} • Benoli Littéraire 🇧🇯
          </span>
        </div>

      </div>

      {/* Actions & controls */}
      <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
        <button
          onClick={handleNextCitation}
          className="py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 font-bold text-xs flex items-center gap-2 border border-slate-700"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Citation suivante</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={handleShareWhatsApp}
            className="py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-2 shadow-md"
          >
            <MessageCircle className="w-4 h-4" />
            <span>Mettre en statut WhatsApp</span>
          </button>

          <button
            onClick={handleCopy}
            className="py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs flex items-center gap-2 border border-slate-700"
          >
            <Copy className="w-3.5 h-3.5 text-amber-400" />
            <span>{copiedText ? "Copié !" : "Copier le texte"}</span>
          </button>
        </div>
      </div>

    </section>
  );
};
