import React from 'react';
import { Heart, MessageCircle, ExternalLink, Shield } from 'lucide-react';
import { BENOLI_INFO } from '../data/benoliData';

interface Props {
  onNavigate: (section: string) => void;
}

export const Footer: React.FC<Props> = ({ onNavigate }) => {
  return (
    <footer className="mt-16 border-t border-amber-500/20 bg-slate-950 text-slate-400 text-xs py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 pb-6 border-b border-slate-800">
          
          {/* Brand & Flag */}
          <div className="flex items-center gap-3 text-center md:text-left">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 to-amber-700 p-0.5 shadow-md flex items-center justify-center font-serif font-black text-slate-950 text-lg">
              B
            </div>
            <div>
              <h4 className="font-serif font-bold text-amber-200 text-sm">
                Benoli Littéraire
              </h4>
              <p className="text-[11px] text-slate-400">
                Auteur béninois : Lokonon B. Tiziano 🇧🇯
              </p>
            </div>
          </div>

          {/* Quick Footer Links */}
          <div className="flex flex-wrap items-center justify-center gap-4 text-slate-300 font-semibold">
            <button onClick={() => onNavigate('home')} className="hover:text-amber-300 transition-colors">
              Accueil
            </button>
            <button onClick={() => onNavigate('romans')} className="hover:text-amber-300 transition-colors">
              Catalogue
            </button>
            <button onClick={() => onNavigate('lyrics')} className="hover:text-amber-300 transition-colors">
              Lyrics
            </button>
            <button onClick={() => onNavigate('about')} className="hover:text-amber-300 transition-colors">
              L'Auteur
            </button>
            <button onClick={() => onNavigate('help')} className="hover:text-amber-300 transition-colors">
              Besoin d'aide
            </button>
          </div>

          {/* Social Links */}
          <div className="flex items-center gap-2">
            <a
              href={`https://wa.me/${BENOLI_INFO.whatsappPrincipal}`}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 rounded-xl bg-emerald-950/60 hover:bg-emerald-900 border border-emerald-500/30 text-emerald-300 transition-colors"
              title="WhatsApp Benoli"
            >
              <MessageCircle className="w-4 h-4" />
            </a>
            <a
              href={BENOLI_INFO.facebookUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 rounded-xl bg-blue-950/60 hover:bg-blue-900 border border-blue-500/30 text-blue-300 transition-colors"
              title="Facebook Officiel Benoli"
            >
              <ExternalLink className="w-4 h-4" />
            </a>
          </div>

        </div>

        {/* Disclaimer & Copyright */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-2 text-center text-[11px] text-slate-500">
          <p>
            © {new Date().getFullYear()} Benoli Littéraire (Lokonon B. Tiziano). Tous droits réservés.
          </p>
          <p className="flex items-center gap-1 justify-center">
            <span>Conçu avec passion pour les lecteurs du Bénin et du monde entier</span>
            <Heart className="w-3 h-3 text-rose-500 fill-rose-500 inline" />
          </p>
        </div>

      </div>
    </footer>
  );
};
