import React, { useState } from 'react';
import { MessageCircle, X, Send, Sparkles, BookOpen, ShoppingBag, HelpCircle } from 'lucide-react';
import { ROMANS, BENOLI_INFO } from '../data/benoliData';

interface Message {
  sender: 'bot' | 'user';
  text: string;
}

interface Props {
  onSelectBook?: (bookId: string) => void;
}

export const AssistantSalome: React.FC<Props> = ({ onSelectBook }) => {
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [input, setInput] = useState<string>('');
  const [messages, setMessages] = useState<Message[]>([
    {
      sender: 'bot',
      text: `Bonjour ! Je suis Salomé, la conseillère littéraire de Benoli. Que souhaites-tu découvrir aujourd'hui ? Tu peux me poser des questions sur les romans, le paiement Mobile Money ou l'auteur !`
    }
  ]);

  const handleSend = (textToSend?: string) => {
    const query = (textToSend || input).trim();
    if (!query) return;

    const newMessages: Message[] = [...messages, { sender: 'user', text: query }];
    setMessages(newMessages);
    if (!textToSend) setInput('');

    // Generate intelligent bot response
    setTimeout(() => {
      let reply = "Je comprends votre curiosité ! Pour toute question spécifique ou pour recevoir les fichiers de lecture directement sur votre téléphone, vous pouvez écrire à Benoli sur WhatsApp au +229 01 49 29 39 39.";
      const lower = query.toLowerCase();

      if (lower.includes('payer') || lower.includes('achat') || lower.includes('mobile money') || lower.includes('prix')) {
        reply = "Les romans sont au tarif unique de 1000 FCFA. Pour acheter, ouvre la fiche du roman et clique sur 'Acheter le roman'. Le paiement se fait en toute sécurité par Mobile Money (MTN, Moov, Celtiis) ou Carte via la plateforme officielle Chariow.";
      } else if (lower.includes('checo') || lower.includes('lénis')) {
        reply = "« Elle m'appelait Chéco » est le roman le plus emblématique de Benoli ! C'est l'histoire touchante de Benoli et Lénis, qui se taquinent depuis le collège Sainte-Claire et dont la relation prend une tournure inattendue à l'université.";
      } else if (lower.includes('cobi') || lower.includes('belvida')) {
        reply = "« Cobi » raconte la rivalité féroce entre Bienvenue (surnommé Cobra/Cobi) et Belvida pour la 1ère place du campus. Mais entre réunions et secrets de famille, la haine cache parfois une autre vérité...";
      } else if (lower.includes('fridaous')) {
        reply = "« Le Cœur de Fridaous » est une magnifique leçon de courage d'une jeune femme béninoise qui apprend la sérigraphie et prend sa place dans la société sans faire de bruit.";
      } else if (lower.includes('auteur') || lower.includes('tiziano') || lower.includes('benoli')) {
        reply = "Benoli (Lokonon B. Tiziano) est un jeune auteur béninois passionné. Il conçoit des romans riches en émotions qui explorent les sentiments humains, les rivalités et sensibilisent les jeunes sur leurs choix de vie.";
      } else if (lower.includes('extrait') || lower.includes('gratuit')) {
        reply = "Tous nos romans disposent d'un extrait gratuit immersif ! Ouvre la fiche d'un roman et clique sur 'Lire l'extrait gratuit'. Tu peux même écouter le texte avec notre synthétiseur audio !";
      }

      setMessages(prev => [...prev, { sender: 'bot', text: reply }]);
    }, 400);
  };

  return (
    <>
      {/* Floating Trigger Button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-5 right-5 z-40 px-4 py-3 rounded-full bg-gradient-to-r from-amber-500 to-amber-700 hover:from-amber-600 hover:to-amber-800 text-slate-950 font-extrabold text-xs sm:text-sm shadow-2xl shadow-amber-950/80 flex items-center gap-2 border border-amber-300 animate-bounce transform hover:scale-105 transition-transform"
          aria-label="Ouvrir l'assistant Salomé"
        >
          <Sparkles className="w-4 h-4 fill-slate-950" />
          <span>💬 Assistant Salomé</span>
        </button>
      )}

      {/* Assistant Modal Window */}
      {isOpen && (
        <div className="fixed bottom-3 right-3 sm:bottom-6 sm:right-6 z-50 w-[94vw] sm:w-[380px] max-h-[580px] bg-slate-900 border-2 border-amber-500/40 rounded-3xl shadow-2xl flex flex-col overflow-hidden animate-in slide-in-from-bottom-5 duration-300">
          
          {/* Header */}
          <div className="p-3.5 bg-gradient-to-r from-amber-600 via-amber-700 to-amber-900 text-slate-950 flex items-center justify-between font-bold">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-slate-950 text-amber-400 flex items-center justify-center font-serif text-sm font-black">
                S
              </div>
              <div>
                <h4 className="text-sm font-serif text-amber-100">Salomé · Conseillère</h4>
                <span className="text-[10px] text-amber-200/80 block font-normal">Benoli Littéraire 🇧🇯</span>
              </div>
            </div>

            <button
              onClick={() => setIsOpen(false)}
              className="p-1 rounded-lg bg-slate-950/40 hover:bg-slate-950/70 text-amber-200 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Quick Suggestions Chips */}
          <div className="p-2 bg-slate-950/80 border-b border-slate-800 flex gap-1.5 overflow-x-auto text-[11px] scrollbar-none">
            {[
              "📚 Recommande-moi un livre",
              "💳 Comment acheter ?",
              "❤️ Parle-moi de Chéco",
              "✍️ Qui est Benoli ?"
            ].map((chip, idx) => (
              <button
                key={idx}
                onClick={() => handleSend(chip)}
                className="px-2.5 py-1 rounded-full bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 whitespace-nowrap border border-amber-500/30 font-medium"
              >
                {chip}
              </button>
            ))}
          </div>

          {/* Chat Messages Body */}
          <div className="flex-1 p-3.5 overflow-y-auto space-y-3 bg-slate-950/40 text-xs">
            {messages.map((msg, idx) => (
              <div
                key={idx}
                className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`max-w-[85%] p-3 rounded-2xl ${
                  msg.sender === 'user'
                    ? 'bg-amber-500 text-slate-950 font-semibold rounded-br-none'
                    : 'bg-slate-800 text-slate-100 border border-slate-700 rounded-bl-none leading-relaxed'
                }`}>
                  {msg.text}
                </div>
              </div>
            ))}
          </div>

          {/* Input Form */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="p-2.5 bg-slate-950 border-t border-slate-800 flex items-center gap-2"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Pose ta question à Salomé..."
              className="flex-1 px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-amber-100 text-xs placeholder-slate-400 focus:outline-none focus:border-amber-400"
            />
            <button
              type="submit"
              disabled={!input.trim()}
              className="p-2 rounded-xl bg-amber-500 text-slate-950 font-bold disabled:opacity-50"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>

        </div>
      )}
    </>
  );
};
