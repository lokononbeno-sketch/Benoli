import React, { useState } from 'react';
import { MessageSquare, Heart, Share2, Send, Sparkles, UserCheck, ShieldCheck, ThumbsUp } from 'lucide-react';
import { ROMANS } from '../data/benoliData';

interface Post {
  id: string;
  author: string;
  location: string;
  time: string;
  bookTitre: string;
  text: string;
  likes: number;
  userLiked?: boolean;
}

const INITIAL_POSTS: Post[] = [
  {
    id: "post-1",
    author: "Priscille D.",
    location: "Cotonou 🇧🇯",
    time: "Il y a 10 min",
    bookTitre: "Elle m'appelait Chéco",
    text: "Je viens de terminer 'Elle m'appelait Chéco' ! Mon dieu, la nostalgie du collège et la tournure à l'université... Lénis et Benoli sont tellement touchants. Lokonon B. Tiziano a vraiment une plume magique ! ❤️",
    likes: 42
  },
  {
    id: "post-2",
    author: "Kévin A.",
    location: "Porto-Novo 🇧🇯",
    time: "Il y a 1h",
    bookTitre: "Cobi",
    text: "La rivalité entre Bienvenue et Belvida avec le 0.02 point de différence m'a fait trop rire ! Mais après, l'histoire prend une dimension tellement profonde avec leurs familles. Un chef-d'œuvre !",
    likes: 38
  },
  {
    id: "post-3",
    author: "Nadège H.",
    location: "Abomey-Calavi 🇧🇯",
    time: "Il y a 3h",
    bookTitre: "Le Cœur de Fridaous",
    text: "Fridaous m'inspire énormément. Son courage pour se former en sérigraphie et sa discrétion parlent à toutes les jeunes femmes du Bénin et d'Afrique. Merci Benoli !",
    likes: 56
  }
];

interface Props {
  onRewardXP?: (points: number) => void;
}

export const CommunitySection: React.FC<Props> = ({ onRewardXP }) => {
  const [posts, setPosts] = useState<Post[]>(INITIAL_POSTS);
  const [newPostText, setNewPostText] = useState('');
  const [newAuthorName, setNewAuthorName] = useState('');
  const [selectedBook, setSelectedBook] = useState<string>(ROMANS[0].titre);

  const handleLike = (id: string) => {
    setPosts(posts.map(p => {
      if (p.id === id) {
        const userLiked = !p.userLiked;
        return {
          ...p,
          userLiked,
          likes: userLiked ? p.likes + 1 : p.likes - 1
        };
      }
      return p;
    }));
  };

  const handleCreatePost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPostText.trim()) return;

    const newPost: Post = {
      id: `post-${Date.now()}`,
      author: newAuthorName.trim() || "Lecteur passionné",
      location: "Bénin 🇧🇯",
      time: "À l'instant",
      bookTitre: selectedBook,
      text: newPostText.trim(),
      likes: 1
    };

    setPosts([newPost, ...posts]);
    setNewPostText('');

    if (onRewardXP) {
      onRewardXP(30);
    }
  };

  return (
    <section className="rounded-3xl bg-slate-900 border border-amber-500/20 p-5 sm:p-7 text-slate-100 shadow-2xl space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-blue-600 to-emerald-500 p-0.5 shadow-lg shadow-blue-950/50 flex items-center justify-center">
            <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
              <MessageSquare className="w-6 h-6 text-blue-400" />
            </div>
          </div>
          <div>
            <span className="text-xs font-extrabold text-amber-400 uppercase tracking-widest block">
              Espace d'échange Facebook Lite Style
            </span>
            <h2 className="text-2xl sm:text-3xl font-serif font-bold text-amber-100">
              Le Club des Lecteurs Benoli
            </h2>
          </div>
        </div>

        <span className="text-xs text-blue-300 bg-blue-950/60 px-3 py-1.5 rounded-full border border-blue-500/30 self-start sm:self-auto font-medium">
          💬 Communauté active de lecteurs
        </span>
      </div>

      {/* New Post Form */}
      <form onSubmit={handleCreatePost} className="p-4 rounded-2xl bg-slate-950/80 border border-amber-500/30 space-y-3">
        <div className="flex flex-col sm:flex-row gap-3">
          <input
            type="text"
            value={newAuthorName}
            onChange={(e) => setNewAuthorName(e.target.value)}
            placeholder="Votre nom ou pseudo..."
            className="flex-1 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-amber-100 text-xs placeholder-slate-400 focus:outline-none focus:border-amber-400"
          />

          <select
            value={selectedBook}
            onChange={(e) => setSelectedBook(e.target.value)}
            className="px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-amber-200 text-xs font-semibold focus:outline-none"
          >
            {ROMANS.map(r => (
              <option key={r.id} value={r.titre}>{r.titre}</option>
            ))}
          </select>
        </div>

        <textarea
          value={newPostText}
          onChange={(e) => setNewPostText(e.target.value)}
          rows={3}
          placeholder="Partagez votre avis, vos émotions ou une réaction sur un roman de Benoli (+30 XP)..."
          className="w-full p-3 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 text-xs placeholder-slate-400 focus:outline-none focus:border-amber-400 resize-none"
        />

        <div className="flex justify-end">
          <button
            type="submit"
            disabled={!newPostText.trim()}
            className="py-2.5 px-5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-700 hover:from-amber-600 hover:to-amber-800 disabled:opacity-50 text-slate-950 font-extrabold text-xs flex items-center gap-2 shadow-md transition-all"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Publier sur le Club (+30 XP)</span>
          </button>
        </div>
      </form>

      {/* Feed List */}
      <div className="space-y-4">
        {posts.map((post) => (
          <div key={post.id} className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-3">
            
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-amber-500 to-amber-700 text-slate-950 font-bold text-xs flex items-center justify-center">
                  {post.author.slice(0, 1)}
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-xs text-amber-200">{post.author}</span>
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  </div>
                  <span className="text-[10px] text-slate-400">{post.location} • {post.time}</span>
                </div>
              </div>

              <span className="text-[11px] font-semibold text-amber-400/90 bg-amber-500/10 px-2.5 py-0.5 rounded-full border border-amber-500/20">
                {post.bookTitre}
              </span>
            </div>

            <p className="text-xs sm:text-sm text-slate-200 leading-relaxed font-sans">
              {post.text}
            </p>

            <div className="flex items-center gap-4 pt-2 border-t border-slate-800/80 text-xs">
              <button
                onClick={() => handleLike(post.id)}
                className={`flex items-center gap-1.5 font-bold transition-colors ${
                  post.userLiked ? 'text-rose-500' : 'text-slate-400 hover:text-rose-400'
                }`}
              >
                <ThumbsUp className={`w-3.5 h-3.5 ${post.userLiked ? 'fill-rose-500' : ''}`} />
                <span>{post.likes} {post.likes > 1 ? 'J\'aime' : 'J\'aime'}</span>
              </button>

              <button
                onClick={() => {
                  const shareText = `« ${post.text} » — ${post.author} sur Benoli Littéraire :`;
                  window.open(`https://wa.me/?text=${encodeURIComponent(shareText + ' ' + window.location.href)}`, '_blank');
                }}
                className="flex items-center gap-1.5 text-slate-400 hover:text-amber-300 font-semibold"
              >
                <Share2 className="w-3.5 h-3.5" />
                <span>Partager</span>
              </button>
            </div>

          </div>
        ))}
      </div>

    </section>
  );
};
