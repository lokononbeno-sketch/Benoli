import React, { useState } from 'react';
import { Search, Filter, BookOpen, Sparkles, ShoppingBag, Heart } from 'lucide-react';
import { Roman, ROMANS } from '../data/benoliData';

interface Props {
  onSelectRoman: (roman: Roman) => void;
  favorites: string[];
  onToggleFavorite: (id: string) => void;
}

export const BookGrid: React.FC<Props> = ({ onSelectRoman, favorites, onToggleFavorite }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedGenre, setSelectedGenre] = useState<string>('Tous');

  // Extract unique genres
  const genres = ['Tous', ...Array.from(new Set(ROMANS.map(r => r.genre)))];

  const filteredRomans = ROMANS.filter(roman => {
    const matchesSearch =
      roman.titre.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (roman.sousTitre && roman.sousTitre.toLowerCase().includes(searchTerm.toLowerCase())) ||
      roman.resume.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesGenre = selectedGenre === 'Tous' || roman.genre === selectedGenre;

    return matchesSearch && matchesGenre;
  });

  return (
    <section className="space-y-6" id="catalogue-section">
      
      {/* Header & Search Bar */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
          <div>
            <span className="text-xs font-extrabold text-amber-400 uppercase tracking-widest block mb-1">
              Bibliothèque complète ({ROMANS.length} œuvres)
            </span>
            <h2 className="text-2xl sm:text-3xl font-serif font-bold text-amber-100">
              Catalogue des Romans Benoli
            </h2>
          </div>

          <span className="text-xs text-slate-400 font-medium bg-slate-900/80 px-3 py-1.5 rounded-full border border-amber-500/20 self-start sm:self-auto">
            ✨ {filteredRomans.length} {filteredRomans.length > 1 ? 'romans trouvés' : 'roman trouvé'}
          </span>
        </div>

        {/* Search input & Genre pills */}
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-center">
          
          <div className="sm:col-span-6 relative">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-amber-400/70" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Chercher un roman, un mot-clé ou une histoire..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-900/90 border border-amber-500/30 text-amber-100 text-sm placeholder-slate-400 focus:outline-none focus:border-amber-400 transition-colors shadow-inner"
            />
          </div>

          {/* Genre filter buttons */}
          <div className="sm:col-span-6 flex gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            {genres.map(genre => (
              <button
                key={genre}
                onClick={() => setSelectedGenre(genre)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors border ${
                  selectedGenre === genre
                    ? 'bg-amber-500 text-slate-950 font-bold border-amber-400 shadow-md shadow-amber-950/40'
                    : 'bg-slate-900/60 text-slate-300 hover:text-amber-200 border-slate-800'
                }`}
              >
                {genre}
              </button>
            ))}
          </div>

        </div>
      </div>

      {/* Book Grid */}
      {filteredRomans.length === 0 ? (
        <div className="text-center py-12 px-4 rounded-3xl bg-slate-900/60 border border-slate-800 space-y-3">
          <p className="text-slate-400 text-sm">
            Aucun roman ne correspond à votre recherche « <strong className="text-amber-300">{searchTerm}</strong> ».
          </p>
          <button
            onClick={() => { setSearchTerm(''); setSelectedGenre('Tous'); }}
            className="text-xs px-4 py-2 rounded-xl bg-amber-500/20 text-amber-300 hover:bg-amber-500/30 font-bold border border-amber-500/40"
          >
            Réinitialiser les filtres
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
          {filteredRomans.map((roman) => {
            const isFav = favorites.includes(roman.id);

            return (
              <div
                key={roman.id}
                className="group relative rounded-2xl bg-slate-900/80 border border-amber-500/20 hover:border-amber-400/60 overflow-hidden shadow-xl hover:shadow-2xl hover:shadow-amber-950/40 transition-all duration-300 flex flex-col transform hover:-translate-y-1"
              >
                {/* Book Cover Image Container */}
                <div className="relative aspect-[2/3] w-full overflow-hidden bg-slate-950">
                  <img
                    src={roman.couverture}
                    alt={`Couverture de ${roman.titre}`}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    loading="lazy"
                  />
                  
                  {/* Top Badge Overlay */}
                  <div className="absolute top-2 left-2 flex flex-col gap-1">
                    {roman.vedette && (
                      <span className="px-2 py-0.5 rounded-md bg-amber-500 text-slate-950 font-black text-[10px] uppercase shadow-md">
                        En vedette
                      </span>
                    )}
                  </div>

                  {/* Favorite Button */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onToggleFavorite(roman.id);
                    }}
                    className="absolute top-2 right-2 p-1.5 rounded-full bg-slate-950/70 text-amber-300 hover:text-rose-400 backdrop-blur-sm border border-white/10 transition-colors"
                    aria-label="Ajouter aux favoris"
                  >
                    <Heart className={`w-4 h-4 ${isFav ? 'fill-rose-500 text-rose-500' : ''}`} />
                  </button>

                  {/* Price Tag Overlay */}
                  <div className="absolute bottom-2 right-2 px-2.5 py-1 rounded-lg bg-slate-950/90 text-amber-300 font-extrabold text-xs border border-amber-500/30 backdrop-blur-md">
                    {roman.prix} FCFA
                  </div>
                </div>

                {/* Book Content Info */}
                <div className="p-3 sm:p-4 flex-1 flex flex-col justify-between space-y-2">
                  <div>
                    <span className="text-[10px] font-bold text-amber-400/80 uppercase tracking-wider block">
                      {roman.genre}
                    </span>
                    <h3 className="font-serif font-bold text-sm sm:text-base text-amber-100 group-hover:text-amber-300 line-clamp-1 leading-snug">
                      {roman.titre}
                    </h3>
                    <p className="text-[11px] text-slate-400 line-clamp-2 mt-1 italic">
                      {roman.sousTitre || roman.resume.slice(0, 70) + '...'}
                    </p>
                  </div>

                  {/* Card Footer Actions */}
                  <div className="pt-2 flex items-center gap-1.5">
                    <button
                      onClick={() => onSelectRoman(roman)}
                      className="flex-1 py-2 px-2.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-200 border border-amber-500/40 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors"
                    >
                      <BookOpen className="w-3.5 h-3.5" />
                      <span>Fiche & Extrait</span>
                    </button>
                  </div>
                </div>

              </div>
            );
          })}
        </div>
      )}

    </section>
  );
};
