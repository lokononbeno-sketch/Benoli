import React, { useState } from 'react';
import { BookOpen, Moon, Sun, Globe, Zap, User, Menu, X, Sparkles, Heart } from 'lucide-react';
import { LANGUAGES, getTranslation } from '../data/translations';
import { BENOLI_INFO } from '../data/benoliData';

interface Props {
  currentLang: string;
  onLanguageChange: (code: string) => void;
  darkMode: boolean;
  onToggleDarkMode: () => void;
  dataSaver: boolean;
  onToggleDataSaver: () => void;
  activeSection: string;
  onNavigate: (section: string) => void;
  userPoints: number;
}

export const Navbar: React.FC<Props> = ({
  currentLang,
  onLanguageChange,
  darkMode,
  onToggleDarkMode,
  dataSaver,
  onToggleDataSaver,
  activeSection,
  onNavigate,
  userPoints
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [langDropdownOpen, setLangDropdownOpen] = useState(false);

  const t = (key: string) => getTranslation(currentLang, key);

  const currentLangObj = LANGUAGES.find(l => l.code === currentLang) || LANGUAGES[0];

  const handleNavClick = (section: string) => {
    onNavigate(section);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 backdrop-blur-md bg-slate-900/90 border-b border-amber-500/20 text-slate-100 transition-all duration-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          
          {/* Brand Logo & Title */}
          <button
            onClick={() => handleNavClick('home')}
            className="flex items-center gap-3 group text-left focus:outline-none"
          >
            <div className="relative w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-gradient-to-br from-amber-400 via-amber-600 to-amber-800 p-0.5 shadow-lg shadow-amber-950/40 group-hover:scale-105 transition-transform">
              <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center overflow-hidden">
                <span className="font-serif font-extrabold text-amber-400 text-lg sm:text-xl tracking-tight">B</span>
              </div>
            </div>
            <div>
              <div className="font-serif font-bold text-base sm:text-lg tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-amber-300 to-amber-500 leading-tight">
                Benoli Littéraire
              </div>
              <div className="text-[10px] sm:text-xs text-amber-200/60 font-medium">
                Lokonon B. Tiziano • Bénin 🇧🇯
              </div>
            </div>
          </button>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-1 bg-slate-950/60 p-1.5 rounded-2xl border border-amber-500/15">
            {[
              { id: 'home', label: 'Accueil' },
              { id: 'romans', label: 'Catalogue' },
              { id: 'lyrics', label: 'Lyrics & Musiques' },
              { id: 'characters', label: 'Personnages' },
              { id: 'quiz', label: 'Quiz' },
              { id: 'community', label: 'Club Lecteurs' },
              { id: 'about', label: 'L\'Auteur' },
            ].map(item => (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`px-3 py-1.5 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
                  activeSection === item.id
                    ? 'bg-gradient-to-r from-amber-500 to-amber-700 text-white shadow-md shadow-amber-900/40'
                    : 'text-slate-300 hover:text-amber-200 hover:bg-slate-800/50'
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>

          {/* Right Action Tools (Points, Data Saver, Language, DarkMode, Profile) */}
          <div className="flex items-center gap-2 sm:gap-3">

            {/* Reader Points Badge */}
            <button
              onClick={() => handleNavClick('rewards')}
              className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-bold hover:bg-amber-500/20 transition-colors"
              title="Vos points de lecteur Benoli"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
              <span>{userPoints} XP</span>
            </button>

            {/* Data Saver Mode Toggle (Esprit Facebook Lite) */}
            <button
              onClick={onToggleDataSaver}
              className={`px-2.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 border transition-all ${
                dataSaver
                  ? 'bg-emerald-600 text-white border-emerald-400 shadow-md shadow-emerald-950/50'
                  : 'bg-slate-800/80 text-slate-300 hover:text-white border-slate-700'
              }`}
              title={dataSaver ? "Mode Data Saver (Lite ON)" : "Activer le mode Lite pour économiser la data"}
            >
              <Zap className={`w-3.5 h-3.5 ${dataSaver ? 'text-amber-300 fill-amber-300' : ''}`} />
              <span className="hidden md:inline">{dataSaver ? 'Lite ON' : 'Lite Data'}</span>
            </button>

            {/* Language Selector Dropdown */}
            <div className="relative">
              <button
                onClick={() => setLangDropdownOpen(!langDropdownOpen)}
                className="px-2.5 py-1.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition-colors"
                aria-label="Sélectionner la langue"
              >
                <span>{currentLangObj.flag}</span>
                <span className="uppercase">{currentLangObj.code}</span>
              </button>

              {langDropdownOpen && (
                <div className="absolute right-0 mt-2 w-44 bg-slate-900 border border-amber-500/30 rounded-2xl shadow-2xl py-2 z-50 max-h-64 overflow-y-auto divide-y divide-slate-800/50">
                  <div className="px-3 py-1.5 text-[11px] font-bold text-amber-400/80 uppercase tracking-wider">
                    Choisir la langue
                  </div>
                  {LANGUAGES.map(lang => (
                    <button
                      key={lang.code}
                      onClick={() => {
                        onLanguageChange(lang.code);
                        setLangDropdownOpen(false);
                      }}
                      className={`w-full px-3 py-2 text-left text-xs flex items-center gap-2 hover:bg-amber-500/20 transition-colors ${
                        currentLang === lang.code ? 'font-bold text-amber-300 bg-amber-500/10' : 'text-slate-300'
                      }`}
                    >
                      <span className="text-base">{lang.flag}</span>
                      <span>{lang.name}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Dark/Light Mode Toggle */}
            <button
              onClick={onToggleDarkMode}
              className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 border border-slate-700 text-amber-300 transition-colors"
              aria-label="Basculer le mode sombre ou clair"
            >
              {darkMode ? <Sun className="w-4 h-4 text-amber-300" /> : <Moon className="w-4 h-4 text-slate-300" />}
            </button>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 border border-slate-700 text-slate-200 transition-colors"
              aria-label="Menu principal"
            >
              {mobileMenuOpen ? <X className="w-5 h-5 text-amber-400" /> : <Menu className="w-5 h-5" />}
            </button>

          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-800 bg-slate-950/95 backdrop-blur-xl px-4 pt-3 pb-6 space-y-2 animate-in slide-in-from-top-4 duration-200">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-xs text-amber-300 font-semibold">
            <span>Navigation Benoli</span>
            <span className="bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded-full">{userPoints} XP Lecteur</span>
          </div>

          {[
            { id: 'home', label: '🏠 Accueil & L\'Arbre Vivant' },
            { id: 'romans', label: '📚 Catalogue des Romans (11+)' },
            { id: 'lyrics', label: '🎵 Lyrics & Musiques Officielles' },
            { id: 'characters', label: '🎭 Guide des Personnages' },
            { id: 'quiz', label: '🧠 Quiz : Quel héros es-tu ?' },
            { id: 'community', label: '💬 Club des Lecteurs' },
            { id: 'quote', label: '📸 Générateur de Citations' },
            { id: 'rewards', label: '🏆 Mes Récompenses & XP' },
            { id: 'about', label: '✍️ À propos de l\'auteur Benoli' },
            { id: 'help', label: '❓ Besoin d\'aide & Contact' },
          ].map(item => (
            <button
              key={item.id}
              onClick={() => handleNavClick(item.id)}
              className={`w-full text-left px-3.5 py-2.5 rounded-xl text-sm font-semibold transition-colors flex items-center justify-between ${
                activeSection === item.id
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                  : 'text-slate-300 hover:bg-slate-800/60'
              }`}
            >
              <span>{item.label}</span>
              {activeSection === item.id && <span className="text-xs text-amber-400">●</span>}
            </button>
          ))}

          <div className="pt-2">
            <a
              href={`https://wa.me/${BENOLI_INFO.whatsappPrincipal}?text=${encodeURIComponent("Bonjour Benoli, je visite ton application web !")}`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full mt-2 py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs text-center block shadow-lg shadow-emerald-950/40"
            >
              💬 Contacter Benoli sur WhatsApp (+229 01 49 29 39 39)
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
